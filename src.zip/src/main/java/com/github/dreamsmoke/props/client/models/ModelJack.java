package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelJack extends ModelInterface {
	
    ModelRenderer mainbox;
    ModelRenderer Spring1;
    ModelRenderer Spring2;
    ModelRenderer Spring3;
    ModelRenderer Spring4;
    ModelRenderer Spring5;
    ModelRenderer Spring6;
    ModelRenderer boxlid;
    ModelRenderer crank1;
    ModelRenderer crank2;
    ModelRenderer crank3;
    ModelRenderer crank4;
    ModelRenderer Nose;
    ModelRenderer Head;

    public ModelJack() {
        super(5);
        this.setTexture("jack.png");
        this.setScale(0.4f);
        this.offsetInvY = 0.2f;
        this.rotation = -90;
        this.scaleItem = 1.5f;
        this.textureWidth = 64;
        this.textureHeight = 64;
        this.mainbox = new ModelRenderer((ModelBase)this, 0, 0);
        this.mainbox.addBox(0.0f, 0.0f, 0.0f, 12, 12, 12);
        this.mainbox.setRotationPoint(-6.0f, 12.0f, -6.0f);
        this.mainbox.setTextureSize(64, 64);
        this.mainbox.mirror = true;
        this.setRotation(this.mainbox, 0.0f, 0.0f, 0.0f);
        this.Spring1 = new ModelRenderer((ModelBase)this, 0, 56);
        this.Spring1.addBox(0.0f, 0.0f, 0.0f, 5, 3, 5);
        this.Spring1.setRotationPoint(-2.5f, 9.0f, -2.5f);
        this.Spring1.setTextureSize(64, 64);
        this.Spring1.mirror = true;
        this.setRotation(this.Spring1, 0.0f, 0.0f, 0.0f);
        this.Spring2 = new ModelRenderer((ModelBase)this, 0, 56);
        this.Spring2.addBox(0.0f, 0.0f, 0.0f, 5, 3, 5);
        this.Spring2.setRotationPoint(-2.5f, 7.0f, -2.5f);
        this.Spring2.setTextureSize(64, 64);
        this.Spring2.mirror = true;
        this.setRotation(this.Spring2, 0.0872665f, 0.3490659f, 0.0f);
        this.Spring3 = new ModelRenderer((ModelBase)this, 0, 56);
        this.Spring3.addBox(0.0f, 0.0f, 0.0f, 5, 3, 5);
        this.Spring3.setRotationPoint(-2.5f, 5.0f, -2.5f);
        this.Spring3.setTextureSize(64, 64);
        this.Spring3.mirror = true;
        this.setRotation(this.Spring3, 0.1396263f, 0.6981317f, 0.0f);
        this.Spring4 = new ModelRenderer((ModelBase)this, 0, 56);
        this.Spring4.addBox(0.0f, 0.0f, 0.0f, 5, 3, 5);
        this.Spring4.setRotationPoint(-2.5f, 3.0f, -3.5f);
        this.Spring4.setTextureSize(64, 64);
        this.Spring4.mirror = true;
        this.setRotation(this.Spring4, 0.1745329f, 1.047198f, 0.0f);
        this.Spring5 = new ModelRenderer((ModelBase)this, 0, 56);
        this.Spring5.addBox(0.0f, 0.0f, 0.0f, 5, 3, 5);
        this.Spring5.setRotationPoint(-2.5f, 1.0f, -4.5f);
        this.Spring5.setTextureSize(64, 64);
        this.Spring5.mirror = true;
        this.setRotation(this.Spring5, 0.2094395f, 1.396263f, 0.0f);
        this.Spring6 = new ModelRenderer((ModelBase)this, 0, 56);
        this.Spring6.addBox(0.0f, 0.0f, 0.0f, 5, 3, 5);
        this.Spring6.setRotationPoint(-2.5f, -1.0f, -5.5f);
        this.Spring6.setTextureSize(64, 64);
        this.Spring6.mirror = true;
        this.setRotation(this.Spring6, 0.2268928f, 1.745329f, 0.0f);
        this.boxlid = new ModelRenderer((ModelBase)this, 0, 24);
        this.boxlid.addBox(0.0f, 0.0f, 0.0f, 12, 6, 12);
        this.boxlid.setRotationPoint(6.0f, 12.0f, -6.0f);
        this.boxlid.setTextureSize(64, 64);
        this.boxlid.mirror = true;
        this.setRotation(this.boxlid, 0.0f, 0.0f, -0.9250245f);
        this.crank1 = new ModelRenderer((ModelBase)this, 50, 0);
        this.crank1.addBox(0.0f, 0.0f, 0.0f, 1, 1, 3);
        this.crank1.setRotationPoint(0.0f, 17.0f, 7.0f);
        this.crank1.setTextureSize(64, 64);
        this.crank1.mirror = true;
        this.setRotation(this.crank1, 0.0f, 0.0f, 0.0f);
        this.crank2 = new ModelRenderer((ModelBase)this, 50, 5);
        this.crank2.addBox(0.0f, 0.0f, 0.0f, 1, 1, 1);
        this.crank2.setRotationPoint(0.0f, 17.0f, 9.0f);
        this.crank2.setTextureSize(64, 64);
        this.crank2.mirror = true;
        this.setRotation(this.crank2, 1.570796f, 0.0f, 0.0f);
        this.crank3 = new ModelRenderer((ModelBase)this, 50, 8);
        this.crank3.addBox(0.0f, 0.0f, 0.0f, 1, 1, 4);
        this.crank3.setRotationPoint(0.0f, 15.0f, 9.0f);
        this.crank3.setTextureSize(64, 64);
        this.crank3.mirror = true;
        this.setRotation(this.crank3, 0.0f, 0.0f, 0.0f);
        this.crank4 = new ModelRenderer((ModelBase)this, 50, 14);
        this.crank4.addBox(0.0f, 0.0f, 0.0f, 2, 2, 1);
        this.crank4.setRotationPoint(-0.5f, 16.5f, 6.0f);
        this.crank4.setTextureSize(64, 64);
        this.crank4.mirror = true;
        this.setRotation(this.crank4, 0.0f, 0.0f, 0.0f);
        this.Nose = new ModelRenderer((ModelBase)this, 32, 44);
        this.Nose.addBox(0.0f, 0.0f, 0.0f, 2, 2, 2);
        this.Nose.setRotationPoint(-5.5f, -5.5f, -9.41f);
        this.Nose.setTextureSize(64, 64);
        this.Nose.mirror = true;
        this.setRotation(this.Nose, 0.1919862f, 0.2094395f, 0.0f);
        this.Head = new ModelRenderer((ModelBase)this, 32, 48);
        this.Head.addBox(0.0f, 0.0f, -1.0f, 8, 8, 8);
        this.Head.setRotationPoint(-5.0f, -8.0f, -12.0f);
        this.Head.setTextureSize(64, 64);
        this.Head.mirror = true;
        this.setRotation(this.Head, 0.1919862f, 0.2094395f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.mainbox.render(f5);
        this.Spring1.render(f5);
        this.Spring2.render(f5);
        this.Spring3.render(f5);
        this.Spring4.render(f5);
        this.Spring5.render(f5);
        this.Spring6.render(f5);
        this.boxlid.render(f5);
        this.crank1.render(f5);
        this.crank2.render(f5);
        this.crank3.render(f5);
        this.crank4.render(f5);
        this.Nose.render(f5);
        this.Head.render(f5);
    }
}

