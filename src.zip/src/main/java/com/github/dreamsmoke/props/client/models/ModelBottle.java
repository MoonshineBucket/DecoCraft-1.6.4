package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelBottle extends ModelInterface {
	
    ModelRenderer wineq;
    ModelRenderer bottle7q;
    ModelRenderer corkq;
    ModelRenderer bottle5q;
    ModelRenderer bottle9q;
    ModelRenderer bottle4q;
    ModelRenderer bottle8q;
    ModelRenderer bottle2q;
    ModelRenderer bottle3q;
    ModelRenderer bottle1q;
    ModelRenderer bottle6q;

    public ModelBottle() {
        super(1);
        this.setTexture("bottle.png");
        this.transparent = true;
        this.textureWidth = 128;
        this.textureHeight = 128;
        this.wineq = new ModelRenderer((ModelBase)this, 8, 20);
        this.wineq.addBox(-1.0f, -1.0f, -6.0f, 2, 2, 7);
        this.wineq.setRotationPoint(0.0f, 17.0f, 0.0f);
        this.wineq.setTextureSize(128, 128);
        this.wineq.mirror = true;
        this.setRotation(this.wineq, 1.570796f, 0.0f, 0.0f);
        this.bottle7q = new ModelRenderer((ModelBase)this, 20, 0);
        this.bottle7q.addBox(1.0f, -1.5f, -5.5f, 1, 3, 7);
        this.bottle7q.setRotationPoint(0.0f, 18.0f, 0.0f);
        this.bottle7q.setTextureSize(128, 128);
        this.bottle7q.mirror = true;
        this.setRotation(this.bottle7q, 1.570796f, 0.0f, 0.0f);
        this.corkq = new ModelRenderer((ModelBase)this, 0, 27);
        this.corkq.addBox(-0.5f, -0.5f, -12.0f, 1, 1, 1);
        this.corkq.setRotationPoint(0.0f, -1.0f, 0.0f);
        this.corkq.setTextureSize(128, 128);
        this.corkq.mirror = true;
        this.setRotation(this.corkq, 1.570796f, 0.0f, 0.0f);
        this.bottle5q = new ModelRenderer((ModelBase)this, 20, 0);
        this.bottle5q.addBox(-2.0f, -1.5f, -5.5f, 1, 3, 7);
        this.bottle5q.setRotationPoint(0.0f, 18.0f, 0.0f);
        this.bottle5q.setTextureSize(128, 128);
        this.bottle5q.mirror = true;
        this.setRotation(this.bottle5q, 1.570796f, 0.0f, 0.0f);
        this.bottle9q = new ModelRenderer((ModelBase)this, 0, 20);
        this.bottle9q.addBox(-1.5f, -1.5f, 1.0f, 3, 3, 1);
        this.bottle9q.setRotationPoint(0.0f, 25.0f, 0.0f);
        this.bottle9q.setTextureSize(128, 128);
        this.bottle9q.mirror = true;
        this.setRotation(this.bottle9q, 1.570796f, 0.0f, 0.0f);
        this.bottle4q = new ModelRenderer((ModelBase)this, 0, 20);
        this.bottle4q.addBox(-1.5f, -1.5f, -6.5f, 3, 3, 1);
        this.bottle4q.setRotationPoint(0.0f, 10.0f, 0.0f);
        this.bottle4q.setTextureSize(128, 128);
        this.bottle4q.mirror = true;
        this.setRotation(this.bottle4q, 1.570796f, 0.0f, 0.0f);
        this.bottle8q = new ModelRenderer((ModelBase)this, 0, 0);
        this.bottle8q.addBox(-1.5f, 1.0f, -5.5f, 3, 1, 7);
        this.bottle8q.setRotationPoint(0.0f, 18.0f, -3.0f);
        this.bottle8q.setTextureSize(128, 128);
        this.bottle8q.mirror = true;
        this.setRotation(this.bottle8q, 1.570796f, 0.0f, 0.0f);
        this.bottle2q = new ModelRenderer((ModelBase)this, 6, 15);
        this.bottle2q.addBox(-0.5f, -0.5f, -10.5f, 1, 1, 3);
        this.bottle2q.setRotationPoint(0.0f, 4.0f, 0.0f);
        this.bottle2q.setTextureSize(128, 128);
        this.bottle2q.mirror = true;
        this.setRotation(this.bottle2q, 1.570796f, 0.0f, 0.0f);
        this.bottle3q = new ModelRenderer((ModelBase)this, 0, 16);
        this.bottle3q.addBox(-1.0f, -1.0f, -7.5f, 2, 2, 1);
        this.bottle3q.setRotationPoint(0.0f, 8.0f, 0.0f);
        this.bottle3q.setTextureSize(128, 128);
        this.bottle3q.mirror = true;
        this.setRotation(this.bottle3q, 1.570796f, 0.0f, 0.0f);
        this.bottle1q = new ModelRenderer((ModelBase)this, 0, 16);
        this.bottle1q.addBox(-1.0f, -1.0f, -11.5f, 2, 2, 1);
        this.bottle1q.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.bottle1q.setTextureSize(128, 128);
        this.bottle1q.mirror = true;
        this.setRotation(this.bottle1q, 1.570796f, 0.0f, 0.0f);
        this.bottle6q = new ModelRenderer((ModelBase)this, 0, 0);
        this.bottle6q.addBox(-1.5f, -2.0f, -5.5f, 3, 1, 7);
        this.bottle6q.setRotationPoint(0.0f, 18.0f, 3.0f);
        this.bottle6q.setTextureSize(128, 128);
        this.bottle6q.mirror = true;
        this.setRotation(this.bottle6q, 1.570796f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.wineq.render(f5);
        this.bottle7q.render(f5);
        this.corkq.render(f5);
        this.bottle5q.render(f5);
        this.bottle9q.render(f5);
        this.bottle4q.render(f5);
        this.bottle8q.render(f5);
        this.bottle2q.render(f5);
        this.bottle3q.render(f5);
        this.bottle1q.render(f5);
        this.bottle6q.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

