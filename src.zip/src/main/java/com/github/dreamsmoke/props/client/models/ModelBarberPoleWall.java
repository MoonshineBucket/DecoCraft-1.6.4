package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelBarberPoleWall extends ModelInterface {
	
    ModelRenderer base1;
    ModelRenderer base2;
    ModelRenderer top1;
    ModelRenderer top2;
    ModelRenderer pole;
    ModelRenderer wall1;
    ModelRenderer wall2;
    ModelRenderer wall3;
    ModelRenderer wall4;
    ModelRenderer glass;

    public ModelBarberPoleWall() {
        super(185);
        this.setTexture("barberpole.png");
        this.transparent = true;
        this.textureWidth = 44;
        this.textureHeight = 18;
        this.base1 = new ModelRenderer((ModelBase)this, 0, 0);
        this.base1.addBox(-2.0f, 23.0f, 1.0f, 4, 1, 4);
        this.base1.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.base1.setTextureSize(44, 18);
        this.base1.mirror = true;
        this.setRotation(this.base1, 0.0f, 0.0f, 0.0f);
        this.base2 = new ModelRenderer((ModelBase)this, 0, 0);
        this.base2.addBox(-3.0f, 21.0f, 0.0f, 6, 2, 6);
        this.base2.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.base2.setTextureSize(44, 18);
        this.base2.mirror = true;
        this.setRotation(this.base2, 0.0f, 0.0f, 0.0f);
        this.top1 = new ModelRenderer((ModelBase)this, 0, 0);
        this.top1.addBox(-3.0f, 9.0f, 0.0f, 6, 2, 6);
        this.top1.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.top1.setTextureSize(44, 18);
        this.top1.mirror = true;
        this.setRotation(this.top1, 0.0f, 0.0f, 0.0f);
        this.top2 = new ModelRenderer((ModelBase)this, 0, 0);
        this.top2.addBox(-2.0f, 8.0f, 1.0f, 4, 1, 4);
        this.top2.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.top2.setTextureSize(44, 18);
        this.top2.mirror = true;
        this.setRotation(this.top2, 0.0f, 0.0f, 0.0f);
        this.pole = new ModelRenderer((ModelBase)this, 0, 4);
        this.pole.addBox(-2.0f, 11.0f, 1.0f, 4, 10, 4);
        this.pole.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.pole.setTextureSize(44, 18);
        this.pole.mirror = true;
        this.setRotation(this.pole, 0.0f, 0.0f, 0.0f);
        this.wall1 = new ModelRenderer((ModelBase)this, 0, 0);
        this.wall1.addBox(-1.5f, 9.0f, 7.0f, 3, 7, 1);
        this.wall1.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.wall1.setTextureSize(44, 18);
        this.wall1.mirror = true;
        this.setRotation(this.wall1, 0.0f, 0.0f, 0.0f);
        this.wall2 = new ModelRenderer((ModelBase)this, 0, 0);
        this.wall2.addBox(-1.5f, 16.0f, 7.0f, 3, 7, 1);
        this.wall2.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.wall2.setTextureSize(44, 18);
        this.wall2.mirror = true;
        this.setRotation(this.wall2, 0.0f, 0.0f, 0.0f);
        this.wall3 = new ModelRenderer((ModelBase)this, 0, 0);
        this.wall3.addBox(-0.5f, 21.0f, 6.0f, 1, 1, 1);
        this.wall3.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.wall3.setTextureSize(44, 18);
        this.wall3.mirror = true;
        this.setRotation(this.wall3, 0.0f, 0.0f, 0.0f);
        this.wall4 = new ModelRenderer((ModelBase)this, 0, 0);
        this.wall4.addBox(-0.5f, 10.0f, 6.0f, 1, 1, 1);
        this.wall4.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.wall4.setTextureSize(44, 18);
        this.wall4.mirror = true;
        this.setRotation(this.wall4, 0.0f, 0.0f, 0.0f);
        this.glass = new ModelRenderer((ModelBase)this, 24, -5);
        this.glass.addBox(-2.5f, 1.0f, 0.5f, 5, 10, 5);
        this.glass.setRotationPoint(0.0f, 10.0f, 0.0f);
        this.glass.setTextureSize(44, 18);
        this.glass.mirror = true;
        this.setRotation(this.glass, 0.0f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.base1.render(f5);
        this.base2.render(f5);
        this.top1.render(f5);
        this.top2.render(f5);
        this.pole.render(f5);
        this.wall1.render(f5);
        this.wall2.render(f5);
        this.wall3.render(f5);
        this.wall4.render(f5);
        this.glass.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

