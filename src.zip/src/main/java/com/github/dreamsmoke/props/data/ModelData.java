package com.github.dreamsmoke.props.data;

import com.github.dreamsmoke.props.Props;

public class ModelData {
	
    public float x1;
    public float x2 = 1.0f;
    public float y1;
    public float y2 = 1.0f;
    public float z1;
    public float z2 = 1.0f;
    public String name;
    public int type = -1;
    public boolean walkthrough = false;
    public int light = 0;

    public ModelData(String name, int type) {
        this.name = name;
        this.type = type;
        Props.data[type] = this;
    }

    public ModelData setLightValue(int i) {
        this.light = i;
        return this;
    }

    public ModelData setBounds(float x1, float y1, float z1, float x2, float y2, float z2) {
        this.x1 = x1;
        this.x2 = x2;
        this.y1 = y1;
        this.y2 = y2;
        this.z1 = z1;
        this.z2 = z2;
        return this;
    }

    public ModelData setWalkthrough() {
        this.walkthrough = true;
        return this;
    }
    
}

