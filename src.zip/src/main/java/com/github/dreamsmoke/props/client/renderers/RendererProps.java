package com.github.dreamsmoke.props.client.renderers;

import com.github.dreamsmoke.props.client.models.*;
import com.github.dreamsmoke.props.client.renderers.ModelInterface;
import com.github.dreamsmoke.props.tiles.TileProps;

import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class RendererProps extends TileEntitySpecialRenderer {
	
    public static ModelInterface[] data = new ModelInterface[500];

    public RendererProps() {
        new ModelBabyCreeper();
        new ModelWoodblocks();
        new ModelSpinningwheel();
        new ModelJack();
        new ModelPaperairplane();
        new ModelGoldingot("goldingot.png", 7);
        new ModelRockinghorse();
        new ModelToySoldier();
        new Modelr2d2();
        new ModelRubikscube("rubikscube.png", 11);
        new ModelToyboat();
        new ModelPlatesfancy();
        new ModelPiano();
        new ModelStainedglass("stainedglassorange.png", 15);
        new ModelStainedglass("stainedglassmagenta.png", 16);
        new ModelStainedglass("stainedglasslightblue.png", 17);
        new ModelStainedglass("stainedglassyellow.png", 18);
        new ModelStainedglass("stainedglasslime.png", 19);
        new ModelStainedglass("stainedglasspink.png", 20);
        new ModelStainedglass("stainedglasscyan.png", 21);
        new ModelStainedglass("stainedglasspurple.png", 22);
        new ModelStainedglass("stainedglassblue.png", 23);
        new ModelStainedglass("stainedglassgreen.png", 24);
        new ModelStainedglass("stainedglassred.png", 25);
        new ModelStainedglass("stainedglasswhite.png", 26);
        new ModelTeaset();
        new ModelTeacup();
        new ModelLongcrate();
        new ModelPicnicbasket();
        new ModelBottle();
        new ModelCuckooclock();
        new ModelGrandfatherclock();
        new ModelPumpkintrio();
        new ModelCradle();
        new ModelXylophone();
        new ModelTrain();
        new ModelDiscord();
        new ModelScarecrow();
        new ModelWinerackfull();
        new ModelWinerackempty();
        new ModelPapelpicado("papelpicadoorange.png", 40);
        new ModelPapelpicado("papelpicadoblack.png", 41);
        new ModelPapelpicado("papelpicadoblue.png", 42);
        new ModelPapelpicado("papelpicadocyan.png", 43);
        new ModelPapelpicado("papelpicadogreen.png", 44);
        new ModelPapelpicado("papelpicadolightblue.png", 45);
        new ModelPapelpicado("papelpicadolime.png", 46);
        new ModelPapelpicado("papelpicadomagenta.png", 47);
        new ModelPapelpicado("papelpicadopink.png", 48);
        new ModelPapelpicado("papelpicadopurple.png", 49);
        new ModelPapelpicado("papelpicadored.png", 50);
        new ModelPapelpicado("papelpicadowhite.png", 51);
        new ModelPapelpicado("papelpicadoyellow.png", 52);
        new ModelOddtrophy("oddtrophygold.png", 53);
        new ModelOddtrophy("oddtrophysilver.png", 54);
        new ModelOddtrophy("oddtrophybronze.png", 55);
        new ModelTrainingdummy();
        new ModelBunny();
        new ModelTeddy();
        new ModelGoldingot("silveringot.png", 59);
        new ModelGoldingot("bronzeingot.png", 60);
        new ModelTanningrack("tanningrack.png", 61);
        new ModelTanningrack("tanningrackleather.png", 62);
        new ModelTanningrack("tanningrackwolf.png", 63);
        new ModelSharpeningstone();
        new ModelIroningboard();
        new ModelClothesline("clothesline1.png", 66);
        new ModelClothesline("clothesline2.png", 67);
        new ModelClothesline("clothesline3.png", 68);
        new ModelClothesline("clothesline4.png", 69);
        new ModelClothesline("clothesline5.png", 70);
        new ModelClothesline("clothesline6.png", 71);
        new ModelWashingboard();
        new ModelBirdhouse();
        new ModelDoghousebig();
        new ModelDoghousesmall();
        new ModelStuffedwolf();
        new ModelPumpkin1();
        new ModelPumpkin2();
        new ModelPumpkin3();
        new ModelDoorbarricade();
        new ModelRubikscube("rubikscubeshuffled.png", 81);
        new ModelPicnictableleft("picnictableleft.png", 82);
        new ModelPicnictablecentre("picnictablecentre.png", 83);
        new ModelPicnictableright("picnictableright.png", 84);
        new ModelGravestone1();
        new ModelGravestone2();
        new ModelGravestone3();
        new ModelParkbin();
        new ModelBarrel();
        new ModelWoodenparkbench();
        new ModelChestkeyhole();
        new ModelTardis();
        new ModelJewelrybox();
        new ModelFallwreath("fallwreath.png", 94);
        new ModelHarp();
        new ModelBrushcomb();
        new ModelSpidercandle();
        new ModelStuffedspider();
        new ModelBeerbarrel();
        new ModelBeerbarrelsmall();
        new ModelBarrelHoriz();
        new ModelBiganchor();
        new ModelAnchor();
        new ModelLuggage();
        new ModelSafe();
        new ModelTurkey();
        new ModelEtchasketch();
        new ModelPhonograph();
        new ModelRope();
        new ModelIcycles();
        new ModelChain("chaintop.png", 111);
        new ModelChain("chainmiddle.png", 112);
        new ModelChain("chainbottom.png", 113);
        new ModelHoneypot();
        new ModelHourglass();
        new ModelBeermug();
        new ModelFlamingo();
        new ModelMirror();
        new ModelGnome();
        new ModelPilgrim();
        new ModelIndian();
        new ModelTelescope();
        new ModelSewingmach();
        new ModelSeesaw();
        new ModelFallwreath("xmaslights.png", 125);
        new ModelFallwreath("xmaswreath1.png", 126);
        new ModelFallwreath("xmaswreath2.png", 127);
        new ModelFallwreath("garland1.png", 128);
        new ModelFallwreath("garland2.png", 129);
        new ModelFallwreath("garland3.png", 130);
        new ModelFallwreath("garland4.png", 131);
        new ModelFallwreath("garland5.png", 132);
        new ModelFallwreath("garland6.png", 133);
        new ModelFallwreath("garland7.png", 134);
        new ModelPresents("presents1.png", 135);
        new ModelPresents("presents2.png", 136);
        new ModelPresents("presents3.png", 137);
        new ModelSwings();
        new ModelPaperlantern("paperlantern.png", 139);
        new ModelToiletpaper();
        new ModelChristmastreebig();
        new ModelChristmastreesmall();
        new ModelTissuebox();
        new ModelSnowglobe();
        new ModelSleigh();
        new ModelSlide();
        new ModelSnowMan();
        new ModelFallwreath("garland8.png", 148);
        new ModelFallwreath("garland9.png", 149);
        new ModelFallwreath("garland10.png", 150);
        new ModelReindeer();
        new ModelReindeerplush();
        new ModelBells();
        new ModelGingerbreadhouse();
        new ModelElfplushie();
        new ModelMilkandcookies();
        new ModelCandycanejar();
        new ModelFallwreath("xmasstocking1.png", 158);
        new ModelFallwreath("xmasstocking2.png", 159);
        new ModelFallwreath("mistletoe.png", 160);
        new ModelSantaplush();
        new ModelPresent1("presents1.png", 162);
        new ModelPresent2("presents1.png", 163);
        new ModelPresent3("presents1.png", 164);
        new ModelPresent1("presents2.png", 165);
        new ModelPresent2("presents2.png", 166);
        new ModelPresent3("presents2.png", 167);
        new ModelPresent1("presents3.png", 168);
        new ModelPresent2("presents3.png", 169);
        new ModelPresent3("presents3.png", 170);
        new ModelChristmastreemedium();
        new ModelGlobe();
        new ModelCrystalBall();
        new ModelGlassRose();
        new ModelEngagementRing();
        new ModelCastle();
        new ModelWindChime();
        new ModelGardenFlamingo();
        new ModelPaperlantern("paperlanternkanji.png", 179);
        new ModelPaperlantern("paperlantern2.png", 180);
        new ModelPaperlantern("paperlantern5.png", 181);
        new ModelPaperlantern("paperlantern3.png", 182);
        new ModelPaperlantern("paperlantern4.png", 183);
        new ModelPaperlantern("paperlantern1.png", 184);
        new ModelBarberPoleWall();
        new ModelBarberPoleGround();
        new ModelPotionsSpilled();
        new ModelPotions();
        new ModelSign("apiary.png", 189);
        new ModelSign("apothecary.png", 190);
        new ModelSign("apothecary2.png", 191);
        new ModelSign("archery.png", 192);
        new ModelSign("baker.png", 193);
        new ModelSign("baker2.png", 194);
        new ModelSign("bank.png", 195);
        new ModelSign("blacksmith.png", 196);
        new ModelSign("bombshop.png", 197);
        new ModelSign("bookshop.png", 198);
        new ModelSign("butcher.png", 199);
        new ModelSign("camping.png", 200);
        new ModelSign("candyshop.png", 201);
        new ModelSign("farming.png", 202);
        new ModelSign("fishery.png", 203);
        new ModelSign("Flowershop.png", 204);
        new ModelSign("generalstore.png", 205);
        new ModelSign("Inn.png", 206);
        new ModelSign("jail.png", 207);
        new ModelSign("jewellry.png", 208);
        new ModelSign("jewellry2.png", 209);
        new ModelSign("lumber.png", 210);
        new ModelSign("magic.png", 211);
        new ModelSign("mapshop.png", 212);
        new ModelSign("mines.png", 213);
        new ModelSign("pet.png", 214);
        new ModelSign("produce.png", 215);
        new ModelSign("pub.png", 216);
        new ModelSign("stables.png", 217);
        new ModelSign("tailor.png", 218);
        new ModelSign("toystore.png", 219);
        new ModelSign("vineyard.png", 220);
        new ModelCoatRack();
        new ModelCheckers();
    }

    public void renderTileEntityAt(TileEntity tileentity, double x, double y, double z, float f) {
        TileProps tile = (TileProps)tileentity;
        GL11.glPushMatrix();
        GL11.glTranslatef((float)((float)x + 0.5f), (float)((float)y), (float)((float)z + 0.5f));
        this.renderModel(tile.type, tile.rotation, false);
        GL11.glPopMatrix();
    }

    public void renderModel(int type, int rot, boolean isInv) {
        ModelInterface model = data[type];
        if (model == null) {
            return;
        }
        
        this.bindTexture(model.resource);
        float rotation = (float)(rot * 360) / 16.0f;
        if (model.transparent) {
            GL11.glEnable((int)2977);
            GL11.glEnable((int)3042);
            GL11.glBlendFunc((int)770, (int)771);
        }
        
        if (isInv) {
            GL11.glTranslatef((float)0.0f, (float)(1.0f * model.scaleY * model.scaleItem), (float)0.0f);
            GL11.glScalef((float)model.scaleItem, (float)model.scaleItem, (float)model.scaleItem);
            GL11.glRotatef((float)180.0f, (float)0.0f, (float)1.0f, (float)0.0f);
        } else {
            GL11.glTranslatef((float)0.0f, (float)(1.5f * model.scaleY), (float)0.0f);
        }
        
        GL11.glRotatef((float)180.0f, (float)0.0f, (float)0.0f, (float)1.0f);
        GL11.glRotatef((float)model.rotation, (float)0.0f, (float)1.0f, (float)0.0f);
        GL11.glRotatef((float)rotation, (float)0.0f, (float)1.0f, (float)0.0f);
        if (!isInv) {
            GL11.glTranslatef((float)model.offsetX, (float)model.offsetY, (float)model.offsetZ);
        } else {
            GL11.glTranslatef((float)0.0f, (float)model.offsetInvY, (float)0.0f);
        }
        
        GL11.glScalef((float)model.scaleX, (float)model.scaleY, (float)model.scaleZ);
        model.render(null, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0625f);
    }
    
}

