package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelBabyCreeper extends ModelInterface {
	
    ModelRenderer Body;
    ModelRenderer Leg1;
    ModelRenderer Leg2;
    ModelRenderer Leg3;
    ModelRenderer Leg4;

    public ModelBabyCreeper() {
        super(0);
        this.setTexture("BabyCreeper.png");
        this.setScale(0.95f);
        this.textureWidth = 32;
        this.textureHeight = 32;
        this.Body = new ModelRenderer((ModelBase)this, 0, 0);
        this.Body.addBox(0.0f, 0.0f, 0.0f, 5, 9, 5);
        this.Body.setRotationPoint(-3.0f, 14.0f, -3.0f);
        this.Leg1 = new ModelRenderer((ModelBase)this, 0, 14);
        this.Leg1.addBox(0.0f, 0.0f, -2.0f, 2, 2, 2);
        this.Leg1.setRotationPoint(1.0f, 22.0f, -2.0f);
        this.Leg1.setTextureSize(32, 32);
        this.Leg1.mirror = true;
        this.setRotation(this.Leg1, 0.0f, 0.0f, 0.0f);
        this.Leg2 = new ModelRenderer((ModelBase)this, 0, 14);
        this.Leg2.addBox(-2.0f, 0.0f, -2.0f, 2, 2, 2);
        this.Leg2.setRotationPoint(-2.0f, 22.0f, -2.0f);
        this.Leg2.setTextureSize(32, 32);
        this.Leg2.mirror = true;
        this.setRotation(this.Leg2, 0.0f, 0.0f, 0.0f);
        this.Leg3 = new ModelRenderer((ModelBase)this, 0, 14);
        this.Leg3.addBox(0.0f, 0.0f, 0.0f, 2, 2, 2);
        this.Leg3.setRotationPoint(1.0f, 22.0f, 1.0f);
        this.Leg3.setTextureSize(32, 32);
        this.Leg3.mirror = true;
        this.setRotation(this.Leg3, 0.0f, 0.0f, 0.0f);
        this.Leg4 = new ModelRenderer((ModelBase)this, 0, 14);
        this.Leg4.addBox(-2.0f, 0.0f, 0.0f, 2, 2, 2);
        this.Leg4.setRotationPoint(-2.0f, 22.0f, 1.0f);
        this.Leg4.setTextureSize(32, 32);
        this.Leg4.mirror = true;
        this.setRotation(this.Leg4, 0.0f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
        this.Body.render(f5);
        this.Leg1.render(f5);
        this.Leg2.render(f5);
        this.Leg3.render(f5);
        this.Leg4.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity) {
        super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
    }
}

