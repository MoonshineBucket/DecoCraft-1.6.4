package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelPaperlantern extends ModelInterface {
	
    ModelRenderer BODY2;
    ModelRenderer MIDROD;
    ModelRenderer TUPDOWN;
    ModelRenderer BODY1;
    ModelRenderer BODY3;
    ModelRenderer deco1;
    ModelRenderer deco2;
    ModelRenderer BODY4;
    ModelRenderer BODY5;
    ModelRenderer deco3;
    ModelRenderer deco4;

    public ModelPaperlantern(String texture, int type) {
        super(type);
        this.setScale(0.5f);
        this.scaleItem = 1.0f;
        this.setTexture(texture);
        this.textureWidth = 256;
        this.textureHeight = 256;
        this.BODY2 = new ModelRenderer((ModelBase)this, 176, 131);
        this.BODY2.addBox(-1.0f, -11.0f, -1.0f, 12, 20, 12);
        this.BODY2.setRotationPoint(-5.0f, 9.0f, -5.0f);
        this.BODY2.setTextureSize(256, 256);
        this.BODY2.mirror = true;
        this.setRotation(this.BODY2, 0.0f, 0.0f, 0.0f);
        this.MIDROD = new ModelRenderer((ModelBase)this, 200, 200);
        this.MIDROD.addBox(-1.0f, -16.0f, -1.0f, 2, 32, 2);
        this.MIDROD.setRotationPoint(0.0f, 8.0f, 0.0f);
        this.MIDROD.setTextureSize(256, 256);
        this.MIDROD.mirror = true;
        this.setRotation(this.MIDROD, 0.0f, 0.0f, 0.0f);
        this.TUPDOWN = new ModelRenderer((ModelBase)this, 183, 10);
        this.TUPDOWN.addBox(-1.0f, -13.0f, -1.0f, 6, 26, 6);
        this.TUPDOWN.setRotationPoint(-2.0f, 8.0f, -2.0f);
        this.TUPDOWN.setTextureSize(256, 256);
        this.TUPDOWN.mirror = true;
        this.setRotation(this.TUPDOWN, 0.0f, 0.0f, 0.0f);
        this.BODY1 = new ModelRenderer((ModelBase)this, 179, 96);
        this.BODY1.addBox(-1.0f, -11.0f, -1.0f, 10, 22, 10);
        this.BODY1.setRotationPoint(-4.0f, 8.0f, -4.0f);
        this.BODY1.setTextureSize(256, 256);
        this.BODY1.mirror = true;
        this.setRotation(this.BODY1, 0.0f, 0.0f, 0.0f);
        this.BODY3 = new ModelRenderer((ModelBase)this, 64, 138);
        this.BODY3.addBox(-1.0f, -10.0f, -1.0f, 20, 18, 20);
        this.BODY3.setRotationPoint(-9.0f, 9.0f, -9.0f);
        this.BODY3.setTextureSize(256, 256);
        this.BODY3.mirror = true;
        this.setRotation(this.BODY3, 0.0f, 0.0f, 0.0f);
        this.deco1 = new ModelRenderer((ModelBase)this, 194, 184);
        this.deco1.addBox(-1.0f, -1.0f, -1.0f, 2, 16, 0);
        this.deco1.setRotationPoint(0.0f, 16.0f, -6.0f);
        this.deco1.setTextureSize(256, 256);
        this.deco1.mirror = true;
        this.setRotation(this.deco1, 0.0f, 0.0f, 0.0f);
        this.deco2 = new ModelRenderer((ModelBase)this, 187, 184);
        this.deco2.addBox(-1.0f, -1.0f, -1.0f, 2, 22, 0);
        this.deco2.setRotationPoint(0.0f, 16.0f, 12.2f);
        this.deco2.setTextureSize(256, 256);
        this.deco2.mirror = true;
        this.setRotation(this.deco2, 0.0f, 0.0f, 0.0f);
        this.BODY4 = new ModelRenderer((ModelBase)this, 64, 177);
        this.BODY4.addBox(-9.0f, -10.0f, -9.0f, 22, 16, 22);
        this.BODY4.setRotationPoint(-2.0f, 10.0f, -2.0f);
        this.BODY4.setTextureSize(256, 256);
        this.BODY4.mirror = true;
        this.setRotation(this.BODY4, 0.0f, 0.0f, 0.0f);
        this.BODY5 = new ModelRenderer((ModelBase)this, 63, 216);
        this.BODY5.addBox(-1.0f, -10.0f, -1.0f, 24, 14, 24);
        this.BODY5.setRotationPoint(-11.0f, 11.0f, -11.0f);
        this.BODY5.setTextureSize(256, 256);
        this.BODY5.mirror = true;
        this.setRotation(this.BODY5, 0.0f, 0.0f, 0.0f);
        this.deco3 = new ModelRenderer((ModelBase)this, 194, 184);
        this.deco3.addBox(-1.0f, -1.0f, -1.0f, 2, 16, 0);
        this.deco3.setRotationPoint(0.0f, 16.0f, 8.0f);
        this.deco3.setTextureSize(256, 256);
        this.deco3.mirror = true;
        this.setRotation(this.deco3, 0.0f, 0.0f, 0.0f);
        this.deco4 = new ModelRenderer((ModelBase)this, 187, 184);
        this.deco4.addBox(-1.0f, -1.0f, -1.0f, 2, 22, 0);
        this.deco4.setRotationPoint(0.0f, 16.0f, -10.2f);
        this.deco4.setTextureSize(256, 256);
        this.deco4.mirror = true;
        this.setRotation(this.deco4, 0.0f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.BODY2.render(f5);
        this.MIDROD.render(f5);
        this.TUPDOWN.render(f5);
        this.BODY1.render(f5);
        this.BODY3.render(f5);
        this.deco1.render(f5);
        this.deco2.render(f5);
        this.BODY4.render(f5);
        this.BODY4.render(f5);
        this.deco3.render(f5);
        this.deco4.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

