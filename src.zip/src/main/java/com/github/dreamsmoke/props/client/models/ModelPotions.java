package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelPotions extends ModelInterface {
	
    ModelRenderer liquid1;
    ModelRenderer liquid2;
    ModelRenderer g1;
    ModelRenderer g2;
    ModelRenderer g3;
    ModelRenderer g4;
    ModelRenderer g5;
    ModelRenderer g7;
    ModelRenderer g8;
    ModelRenderer g9;
    ModelRenderer g10;
    ModelRenderer g11;
    ModelRenderer g12;
    ModelRenderer g13;
    ModelRenderer g14;
    ModelRenderer g15;

    public ModelPotions() {
        super(188);
        this.setTexture("potiontexture.png");
        this.transparent = true;
        this.textureWidth = 25;
        this.textureHeight = 15;
        this.liquid1 = new ModelRenderer((ModelBase)this, 0, 8);
        this.liquid1.addBox(-5.0f, 20.0f, 1.0f, 4, 3, 4);
        this.liquid1.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.liquid1.setTextureSize(25, 15);
        this.liquid1.mirror = true;
        this.setRotation(this.liquid1, 0.0f, -0.2617994f, 0.0f);
        this.liquid2 = new ModelRenderer((ModelBase)this, 12, 8);
        this.liquid2.addBox(2.5f, 21.7f, -1.5f, 2, 2, 2);
        this.liquid2.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.liquid2.setTextureSize(25, 15);
        this.liquid2.mirror = true;
        this.setRotation(this.liquid2, 0.0f, 0.0f, 0.0f);
        this.g1 = new ModelRenderer((ModelBase)this, 0, 0);
        this.g1.addBox(-5.0f, 23.0f, 1.0f, 4, 1, 4);
        this.g1.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.g1.setTextureSize(25, 15);
        this.g1.mirror = true;
        this.setRotation(this.g1, 0.0f, -0.2617994f, 0.0f);
        this.g2 = new ModelRenderer((ModelBase)this, 0, 0);
        this.g2.addBox(-5.0f, 19.0f, 0.0f, 4, 4, 1);
        this.g2.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.g2.setTextureSize(25, 15);
        this.g2.mirror = true;
        this.setRotation(this.g2, 0.0f, -0.2617994f, 0.0f);
        this.g3 = new ModelRenderer((ModelBase)this, 0, 0);
        this.g3.addBox(-6.0f, 19.0f, 1.0f, 1, 4, 4);
        this.g3.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.g3.setTextureSize(25, 15);
        this.g3.mirror = true;
        this.setRotation(this.g3, 0.0f, -0.2617994f, 0.0f);
        this.g4 = new ModelRenderer((ModelBase)this, 0, 0);
        this.g4.addBox(-5.0f, 19.0f, 5.0f, 4, 4, 1);
        this.g4.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.g4.setTextureSize(25, 15);
        this.g4.mirror = true;
        this.setRotation(this.g4, 0.0f, -0.2617994f, 0.0f);
        this.g5 = new ModelRenderer((ModelBase)this, 0, 0);
        this.g5.addBox(-1.0f, 19.0f, 1.0f, 1, 4, 4);
        this.g5.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.g5.setTextureSize(25, 15);
        this.g5.mirror = true;
        this.setRotation(this.g5, 0.0f, -0.2617994f, 0.0f);
        this.g7 = new ModelRenderer((ModelBase)this, 0, 0);
        this.g7.addBox(-5.0f, 18.0f, 1.0f, 4, 1, 4);
        this.g7.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.g7.setTextureSize(25, 15);
        this.g7.mirror = true;
        this.setRotation(this.g7, 0.0f, -0.2617994f, 0.0f);
        this.g8 = new ModelRenderer((ModelBase)this, 0, 0);
        this.g8.addBox(-4.5f, 17.0f, 1.5f, 3, 1, 3);
        this.g8.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.g8.setTextureSize(25, 15);
        this.g8.mirror = true;
        this.setRotation(this.g8, 0.0f, -0.2617994f, 0.0f);
        this.g9 = new ModelRenderer((ModelBase)this, 0, 0);
        this.g9.addBox(-4.0f, 16.0f, 2.0f, 2, 1, 2);
        this.g9.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.g9.setTextureSize(25, 15);
        this.g9.mirror = true;
        this.setRotation(this.g9, 0.0f, -0.2617994f, 0.0f);
        this.g10 = new ModelRenderer((ModelBase)this, 0, 0);
        this.g10.addBox(-3.5f, 14.25f, 2.5f, 1, 2, 1);
        this.g10.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.g10.setTextureSize(25, 15);
        this.g10.mirror = true;
        this.setRotation(this.g10, 0.0f, -0.2617994f, 0.0f);
        this.g11 = new ModelRenderer((ModelBase)this, 0, 0);
        this.g11.addBox(-4.0f, 13.5f, 2.0f, 2, 1, 2);
        this.g11.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.g11.setTextureSize(25, 15);
        this.g11.mirror = true;
        this.setRotation(this.g11, 0.0f, -0.2617994f, 0.0f);
        this.g12 = new ModelRenderer((ModelBase)this, 0, 8);
        this.g12.addBox(-3.5f, 13.0f, 2.5f, 1, 1, 1);
        this.g12.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.g12.setTextureSize(25, 15);
        this.g12.mirror = true;
        this.setRotation(this.g12, 0.0f, -0.2617994f, 0.0f);
        this.g13 = new ModelRenderer((ModelBase)this, 0, 0);
        this.g13.addBox(2.0f, 21.0f, -2.0f, 3, 3, 3);
        this.g13.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.g13.setTextureSize(25, 15);
        this.g13.mirror = true;
        this.setRotation(this.g13, 0.0f, 0.0f, 0.0f);
        this.g14 = new ModelRenderer((ModelBase)this, 0, 0);
        this.g14.addBox(2.5f, 20.5f, -1.5f, 2, 1, 2);
        this.g14.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.g14.setTextureSize(25, 15);
        this.g14.mirror = true;
        this.setRotation(this.g14, 0.0f, 0.0f, 0.0f);
        this.g15 = new ModelRenderer((ModelBase)this, 0, 0);
        this.g15.addBox(3.0f, 19.0f, -1.0f, 1, 2, 1);
        this.g15.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.g15.setTextureSize(25, 15);
        this.g15.mirror = true;
        this.setRotation(this.g15, 0.0f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.liquid1.render(f5);
        this.liquid2.render(f5);
        this.g1.render(f5);
        this.g2.render(f5);
        this.g3.render(f5);
        this.g4.render(f5);
        this.g5.render(f5);
        this.g7.render(f5);
        this.g8.render(f5);
        this.g9.render(f5);
        this.g10.render(f5);
        this.g11.render(f5);
        this.g12.render(f5);
        this.g13.render(f5);
        this.g14.render(f5);
        this.g15.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

