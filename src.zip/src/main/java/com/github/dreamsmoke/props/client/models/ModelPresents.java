package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelPresents extends ModelInterface {
	
    ModelRenderer Shape1;
    ModelRenderer Shape1lid;
    ModelRenderer Shape2;
    ModelRenderer Shape2lid;
    ModelRenderer Shape3;
    ModelRenderer Shape3lid;
    ModelRenderer bow1;
    ModelRenderer bow2;
    ModelRenderer bow3;
    ModelRenderer bow4;
    ModelRenderer bow5;
    ModelRenderer bow6;

    public ModelPresents(String texture, int type) {
        super(type);
        this.setScale(0.4f);
        this.scaleItem = 1.1f;
        this.setTexture(texture);
        this.transparent = true;
        this.textureWidth = 256;
        this.textureHeight = 256;
        this.Shape1 = new ModelRenderer((ModelBase)this, 0, 82);
        this.Shape1.addBox(-8.0f, 0.0f, -10.0f, 20, 8, 16);
        this.Shape1.setRotationPoint(-17.0f, 16.0f, -7.0f);
        this.Shape1.setTextureSize(256, 256);
        this.Shape1.mirror = true;
        this.setRotation(this.Shape1, 0.0f, 0.2617994f, 0.0f);
        this.Shape1lid = new ModelRenderer((ModelBase)this, 76, 82);
        this.Shape1lid.addBox(-8.0f, 0.0f, -10.0f, 22, 4, 18);
        this.Shape1lid.setRotationPoint(-18.0f, 12.0f, -8.0f);
        this.Shape1lid.setTextureSize(256, 256);
        this.Shape1lid.mirror = true;
        this.setRotation(this.Shape1lid, 0.0f, 0.2617994f, 0.0f);
        this.Shape2 = new ModelRenderer((ModelBase)this, 0, 0);
        this.Shape2.addBox(-6.0f, 0.0f, 1.0f, 18, 21, 18);
        this.Shape2.setRotationPoint(-4.0f, 3.0f, 0.0f);
        this.Shape2.setTextureSize(256, 256);
        this.Shape2.mirror = true;
        this.setRotation(this.Shape2, 0.0f, 0.0f, 0.0f);
        this.Shape2lid = new ModelRenderer((ModelBase)this, 76, 0);
        this.Shape2lid.addBox(-6.0f, 0.0f, 1.0f, 20, 4, 20);
        this.Shape2lid.setRotationPoint(-5.0f, -1.0f, -1.0f);
        this.Shape2lid.setTextureSize(256, 256);
        this.Shape2lid.mirror = true;
        this.setRotation(this.Shape2lid, 0.0f, 0.0f, 0.0f);
        this.Shape3 = new ModelRenderer((ModelBase)this, 0, 46);
        this.Shape3.addBox(-8.0f, 0.0f, -8.0f, 16, 12, 16);
        this.Shape3.setRotationPoint(12.0f, 12.0f, -10.0f);
        this.Shape3.setTextureSize(256, 256);
        this.Shape3.mirror = true;
        this.setRotation(this.Shape3, 0.0f, -0.2617994f, 0.0f);
        this.Shape3lid = new ModelRenderer((ModelBase)this, 70, 46);
        this.Shape3lid.addBox(-8.0f, 0.0f, -8.0f, 18, 4, 18);
        this.Shape3lid.setRotationPoint(11.0f, 8.0f, -11.0f);
        this.Shape3lid.setTextureSize(256, 256);
        this.Shape3lid.mirror = true;
        this.setRotation(this.Shape3lid, 0.0f, -0.2617994f, 0.0f);
        this.bow1 = new ModelRenderer((ModelBase)this, 160, 0);
        this.bow1.addBox(-5.5f, 0.0f, 1.0f, 13, 8, 0);
        this.bow1.setRotationPoint(-2.0f, -9.0f, 9.0f);
        this.bow1.setTextureSize(256, 256);
        this.bow1.mirror = true;
        this.setRotation(this.bow1, 0.0f, 0.0f, 0.0f);
        this.bow2 = new ModelRenderer((ModelBase)this, 160, 8);
        this.bow2.addBox(-1.0f, 0.0f, -5.5f, 0, 8, 13);
        this.bow2.setRotationPoint(0.0f, -9.0f, 9.0f);
        this.bow2.setTextureSize(256, 256);
        this.bow2.mirror = true;
        this.setRotation(this.bow2, 0.0f, 0.0f, 0.0f);
        this.bow3 = new ModelRenderer((ModelBase)this, 160, 46);
        this.bow3.addBox(-5.5f, 0.0f, 1.0f, 13, 8, 0);
        this.bow3.setRotationPoint(11.0f, 0.0f, -11.0f);
        this.bow3.setTextureSize(256, 256);
        this.bow3.mirror = true;
        this.setRotation(this.bow3, 0.0f, -0.2617994f, 0.0f);
        this.bow4 = new ModelRenderer((ModelBase)this, 160, 55);
        this.bow4.addBox(-1.0f, 0.0f, -5.5f, 0, 8, 13);
        this.bow4.setRotationPoint(13.0f, 0.0f, -11.0f);
        this.bow4.setTextureSize(256, 256);
        this.bow4.mirror = true;
        this.setRotation(this.bow4, 0.0f, -0.2617994f, 0.0f);
        this.bow5 = new ModelRenderer((ModelBase)this, 160, 85);
        this.bow5.addBox(-5.5f, 0.0f, 1.0f, 13, 8, 0);
        this.bow5.setRotationPoint(-16.0f, 4.0f, -10.0f);
        this.bow5.setTextureSize(256, 256);
        this.bow5.mirror = true;
        this.setRotation(this.bow5, 0.0f, 0.2617994f, 0.0f);
        this.bow6 = new ModelRenderer((ModelBase)this, 160, 94);
        this.bow6.addBox(-1.0f, 0.0f, -5.5f, 0, 8, 13);
        this.bow6.setRotationPoint(-14.0f, 4.0f, -10.0f);
        this.bow6.setTextureSize(256, 256);
        this.bow6.mirror = true;
        this.setRotation(this.bow6, 0.0f, 0.2617994f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.Shape1.render(f5);
        this.Shape1lid.render(f5);
        this.Shape2.render(f5);
        this.Shape2lid.render(f5);
        this.Shape3.render(f5);
        this.Shape3lid.render(f5);
        this.bow1.render(f5);
        this.bow2.render(f5);
        this.bow3.render(f5);
        this.bow4.render(f5);
        this.bow5.render(f5);
        this.bow6.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

