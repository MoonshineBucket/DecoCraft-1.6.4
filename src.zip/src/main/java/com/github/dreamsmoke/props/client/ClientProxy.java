package com.github.dreamsmoke.props.client;

import com.github.dreamsmoke.props.Props;
import com.github.dreamsmoke.props.client.renderers.RenderPropsInv;
import com.github.dreamsmoke.props.client.renderers.RendererProps;
import com.github.dreamsmoke.props.common.CommonProxy;
import com.github.dreamsmoke.props.tiles.TileProps;

import cpw.mods.fml.client.registry.ClientRegistry;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.item.Item;
import net.minecraftforge.client.IItemRenderer;
import net.minecraftforge.client.MinecraftForgeClient;

public class ClientProxy extends CommonProxy {
	
    public static RendererProps renderer;

    @Override
    public void load() {
        renderer = new RendererProps();
        ClientRegistry.bindTileEntitySpecialRenderer(TileProps.class, (TileEntitySpecialRenderer)renderer);
        MinecraftForgeClient.registerItemRenderer((int)Props.props.itemID, (IItemRenderer)new RenderPropsInv());
    }
    
}

