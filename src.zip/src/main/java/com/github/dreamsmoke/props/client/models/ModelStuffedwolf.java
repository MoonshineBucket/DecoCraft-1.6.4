package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelStuffedwolf extends ModelInterface {
	
    ModelRenderer WolfHead;
    ModelRenderer Body;
    ModelRenderer Mane;
    ModelRenderer Leg1;
    ModelRenderer Leg2;
    ModelRenderer Leg3;
    ModelRenderer Leg4;
    ModelRenderer Tail;
    ModelRenderer Ear1;
    ModelRenderer Ear2;
    ModelRenderer Nose;

    public ModelStuffedwolf() {
        super(76);
        this.setTexture("stuffedwolf.png");
        this.setScale(0.5f);
        this.scaleItem = 2.0f;
        this.textureWidth = 64;
        this.textureHeight = 32;
        this.WolfHead = new ModelRenderer((ModelBase)this, 0, 0);
        this.WolfHead.addBox(-3.0f, -3.0f, -2.0f, 6, 6, 4);
        this.WolfHead.setRotationPoint(0.0f, 13.5f, -4.0f);
        this.WolfHead.setTextureSize(64, 32);
        this.WolfHead.mirror = true;
        this.setRotation(this.WolfHead, -0.2268928f, 0.0f, 0.1047198f);
        this.Body = new ModelRenderer((ModelBase)this, 18, 14);
        this.Body.addBox(-4.0f, -2.0f, -3.0f, 6, 9, 6);
        this.Body.setRotationPoint(1.0f, 18.0f, 3.0f);
        this.Body.setTextureSize(64, 32);
        this.Body.mirror = true;
        this.setRotation(this.Body, 0.6073746f, 0.0f, 0.0f);
        this.Mane = new ModelRenderer((ModelBase)this, 21, 0);
        this.Mane.addBox(-4.0f, -3.0f, -3.0f, 8, 6, 7);
        this.Mane.setRotationPoint(0.0f, 16.0f, 0.0f);
        this.Mane.setTextureSize(64, 32);
        this.Mane.mirror = true;
        this.setRotation(this.Mane, 1.186824f, 0.0f, 0.0f);
        this.Leg1 = new ModelRenderer((ModelBase)this, 0, 18);
        this.Leg1.addBox(-1.0f, 0.0f, -1.0f, 2, 8, 2);
        this.Leg1.setRotationPoint(-1.5f, 23.0f, 6.0f);
        this.Leg1.setTextureSize(64, 32);
        this.Leg1.mirror = true;
        this.setRotation(this.Leg1, -1.570796f, 0.0f, 0.0f);
        this.Leg2 = new ModelRenderer((ModelBase)this, 0, 18);
        this.Leg2.addBox(-1.0f, 0.0f, -1.0f, 2, 8, 2);
        this.Leg2.setRotationPoint(1.5f, 23.0f, 6.0f);
        this.Leg2.setTextureSize(64, 32);
        this.Leg2.mirror = true;
        this.setRotation(this.Leg2, -1.570796f, 0.0f, 0.0f);
        this.Leg3 = new ModelRenderer((ModelBase)this, 0, 18);
        this.Leg3.addBox(-1.0f, 0.0f, -1.0f, 2, 8, 2);
        this.Leg3.setRotationPoint(-1.5f, 16.0f, -3.0f);
        this.Leg3.setTextureSize(64, 32);
        this.Leg3.mirror = true;
        this.setRotation(this.Leg3, -0.2792527f, 0.0f, 0.0f);
        this.Leg4 = new ModelRenderer((ModelBase)this, 0, 18);
        this.Leg4.addBox(-1.0f, 0.0f, -1.0f, 2, 8, 2);
        this.Leg4.setRotationPoint(1.5f, 16.0f, -3.0f);
        this.Leg4.setTextureSize(64, 32);
        this.Leg4.mirror = true;
        this.setRotation(this.Leg4, -0.2792527f, 0.0f, 0.0f);
        this.Tail = new ModelRenderer((ModelBase)this, 9, 18);
        this.Tail.addBox(-1.0f, 0.0f, -1.0f, 2, 8, 2);
        this.Tail.setRotationPoint(-1.0f, 21.0f, 8.0f);
        this.Tail.setTextureSize(64, 32);
        this.Tail.mirror = true;
        this.setRotation(this.Tail, 2.753226f, 0.0f, 0.3316126f);
        this.Ear1 = new ModelRenderer((ModelBase)this, 16, 14);
        this.Ear1.addBox(-3.0f, -5.0f, 0.0f, 2, 2, 1);
        this.Ear1.setRotationPoint(0.0f, 13.5f, -4.0f);
        this.Ear1.setTextureSize(64, 32);
        this.Ear1.mirror = true;
        this.setRotation(this.Ear1, 0.0f, 0.0f, 0.1047198f);
        this.Ear2 = new ModelRenderer((ModelBase)this, 16, 14);
        this.Ear2.addBox(1.0f, -5.0f, 0.0f, 2, 2, 1);
        this.Ear2.setRotationPoint(0.0f, 13.5f, -4.0f);
        this.Ear2.setTextureSize(64, 32);
        this.Ear2.mirror = true;
        this.setRotation(this.Ear2, 0.0f, 0.0f, 0.1047198f);
        this.Nose = new ModelRenderer((ModelBase)this, 0, 10);
        this.Nose.addBox(-2.0f, 0.0f, -5.0f, 3, 3, 4);
        this.Nose.setRotationPoint(0.5f, 13.5f, -4.0f);
        this.Nose.setTextureSize(64, 32);
        this.Nose.mirror = true;
        this.setRotation(this.Nose, -0.2268928f, 0.0f, 0.1047198f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.WolfHead.render(f5);
        this.Body.render(f5);
        this.Mane.render(f5);
        this.Leg1.render(f5);
        this.Leg2.render(f5);
        this.Leg3.render(f5);
        this.Leg4.render(f5);
        this.Tail.render(f5);
        this.Ear1.render(f5);
        this.Ear2.render(f5);
        this.Nose.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

