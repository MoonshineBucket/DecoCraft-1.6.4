package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelPresent3 extends ModelInterface {
	
    ModelRenderer Shape1;
    ModelRenderer Shape1lid;
    ModelRenderer bow5;
    ModelRenderer bow6;

    public ModelPresent3(String texture, int type) {
        super(type);
        this.setScale(0.4f);
        this.scaleItem = 1.1f;
        this.setTexture(texture);
        this.transparent = true;
        this.textureWidth = 256;
        this.textureHeight = 256;
        this.Shape1 = new ModelRenderer((ModelBase)this, 0, 82);
        this.Shape1.addBox(-8.0f, 0.0f, -10.0f, 20, 8, 16);
        this.Shape1.setRotationPoint(-2.0f, 16.0f, 2.0f);
        this.Shape1.setTextureSize(256, 256);
        this.Shape1.mirror = true;
        this.setRotation(this.Shape1, 0.0f, 0.0f, 0.0f);
        this.Shape1lid = new ModelRenderer((ModelBase)this, 76, 82);
        this.Shape1lid.addBox(-8.0f, 0.0f, -10.0f, 22, 4, 18);
        this.Shape1lid.setRotationPoint(-3.0f, 12.0f, 1.0f);
        this.Shape1lid.setTextureSize(256, 256);
        this.Shape1lid.mirror = true;
        this.setRotation(this.Shape1lid, 0.0f, 0.0f, 0.0f);
        this.bow5 = new ModelRenderer((ModelBase)this, 160, 85);
        this.bow5.addBox(-5.5f, 0.0f, 1.0f, 13, 8, 0);
        this.bow5.setRotationPoint(-1.0f, 4.0f, -1.0f);
        this.bow5.setTextureSize(256, 256);
        this.bow5.mirror = true;
        this.setRotation(this.bow5, 0.0f, 0.0f, 0.0f);
        this.bow6 = new ModelRenderer((ModelBase)this, 160, 94);
        this.bow6.addBox(-1.0f, 0.0f, -5.5f, 0, 8, 13);
        this.bow6.setRotationPoint(1.0f, 4.0f, -1.0f);
        this.bow6.setTextureSize(256, 256);
        this.bow6.mirror = true;
        this.setRotation(this.bow6, 0.0f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.Shape1.render(f5);
        this.Shape1lid.render(f5);
        this.bow5.render(f5);
        this.bow6.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

