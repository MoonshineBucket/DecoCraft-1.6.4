package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelGlobe extends ModelInterface {
	
    ModelRenderer base1;
    ModelRenderer base2;
    ModelRenderer base3;
    ModelRenderer base4;
    ModelRenderer Shape1;
    ModelRenderer Globe;
    ModelRenderer Shape3;
    ModelRenderer axis;
    ModelRenderer Shape2;

    public ModelGlobe() {
        super(172);
        this.setTexture("globe.png");
        this.setScale(0.7f);
        this.transparent = true;
        this.textureWidth = 64;
        this.textureHeight = 64;
        this.base1 = new ModelRenderer((ModelBase)this, 0, 0);
        this.base1.addBox(-6.0f, 0.0f, -6.0f, 12, 1, 12);
        this.base1.setRotationPoint(0.0f, 23.0f, 0.0f);
        this.base1.setTextureSize(64, 64);
        this.base1.mirror = true;
        this.setRotation(this.base1, 0.0f, 0.0f, 0.0f);
        this.base2 = new ModelRenderer((ModelBase)this, 0, 0);
        this.base2.addBox(-5.0f, 0.0f, -5.0f, 10, 1, 10);
        this.base2.setRotationPoint(0.0f, 22.0f, 0.0f);
        this.base2.setTextureSize(64, 64);
        this.base2.mirror = true;
        this.setRotation(this.base2, 0.0f, 0.0f, 0.0f);
        this.base3 = new ModelRenderer((ModelBase)this, 0, 0);
        this.base3.addBox(-4.0f, 0.0f, -4.0f, 8, 1, 8);
        this.base3.setRotationPoint(0.0f, 21.0f, 0.0f);
        this.base3.setTextureSize(64, 64);
        this.base3.mirror = true;
        this.setRotation(this.base3, 0.0f, 0.0f, 0.0f);
        this.base4 = new ModelRenderer((ModelBase)this, 0, 0);
        this.base4.addBox(-0.5f, 0.0f, -0.5f, 1, 3, 1);
        this.base4.setRotationPoint(0.0f, 18.0f, 0.0f);
        this.base4.setTextureSize(64, 64);
        this.base4.mirror = true;
        this.setRotation(this.base4, 0.0f, 0.0f, 0.0f);
        this.Shape1 = new ModelRenderer((ModelBase)this, 0, 0);
        this.Shape1.addBox(-1.0f, 0.0f, -1.5f, 10, 1, 3);
        this.Shape1.setRotationPoint(-1.0f, 17.0f, 0.0f);
        this.Shape1.setTextureSize(64, 64);
        this.Shape1.mirror = true;
        this.setRotation(this.Shape1, 0.0f, 0.0f, 0.0f);
        this.Globe = new ModelRenderer((ModelBase)this, 0, 37);
        this.Globe.addBox(-6.5f, 0.0f, -6.5f, 13, 13, 13);
        this.Globe.setRotationPoint(0.0f, 3.0f, 0.0f);
        this.Globe.setTextureSize(64, 64);
        this.Globe.mirror = true;
        this.setRotation(this.Globe, 0.0f, 0.0f, 0.0f);
        this.Shape3 = new ModelRenderer((ModelBase)this, 0, 0);
        this.Shape3.addBox(0.0f, 0.0f, -1.5f, 1, 15, 3);
        this.Shape3.setRotationPoint(7.0f, 2.0f, 0.0f);
        this.Shape3.setTextureSize(64, 64);
        this.Shape3.mirror = true;
        this.setRotation(this.Shape3, 0.0f, 0.0f, 0.0f);
        this.axis = new ModelRenderer((ModelBase)this, 0, 19);
        this.axis.addBox(0.0f, 0.0f, -0.5f, 1, 15, 1);
        this.axis.setRotationPoint(0.0f, 2.0f, 0.0f);
        this.axis.setTextureSize(64, 64);
        this.axis.mirror = true;
        this.setRotation(this.axis, 0.0f, 0.0f, 0.0f);
        this.Shape2 = new ModelRenderer((ModelBase)this, 0, 0);
        this.Shape2.addBox(-1.0f, 0.0f, -1.5f, 10, 1, 3);
        this.Shape2.setRotationPoint(-1.0f, 1.0f, 0.0f);
        this.Shape2.setTextureSize(64, 64);
        this.Shape2.mirror = true;
        this.setRotation(this.Shape2, 0.0f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.base1.render(f5);
        this.base2.render(f5);
        this.base3.render(f5);
        this.base4.render(f5);
        this.Shape1.render(f5);
        this.Globe.render(f5);
        this.Shape3.render(f5);
        this.axis.render(f5);
        this.Shape2.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

