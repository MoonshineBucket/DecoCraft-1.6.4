package com.github.dreamsmoke.props.client.renderers;

import com.github.dreamsmoke.props.client.ClientProxy;
import com.github.dreamsmoke.props.client.renderers.RendererProps;
import com.github.dreamsmoke.props.items.ItemProps;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.IItemRenderer;

public class RenderPropsInv implements IItemRenderer {
	
    public boolean handleRenderType(ItemStack item, IItemRenderer.ItemRenderType type) {
        return true;
    }

    public boolean shouldUseRenderHelper(IItemRenderer.ItemRenderType type, ItemStack item, IItemRenderer.ItemRendererHelper helper) {
        return true;
    }

    public void renderItem(IItemRenderer.ItemRenderType type, ItemStack itemstack, Object ... data) {
        ItemProps item = (ItemProps)itemstack.getItem();
        ClientProxy.renderer.renderModel(itemstack.getItemDamage(), 0, true);
    }
    
}

