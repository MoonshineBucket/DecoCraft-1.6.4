package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class Modelr2d2 extends ModelInterface {
	
    ModelRenderer r2rightleg;
    ModelRenderer r2rightfoot;
    ModelRenderer r2leftfoot;
    ModelRenderer r2leftleg;
    ModelRenderer Selection_Group;

    public Modelr2d2() {
        super(10);
        this.setTexture("r2d2.png");
        this.setScale(0.33f);
        this.scaleItem = 3.0f;
        this.textureWidth = 64;
        this.textureHeight = 32;
        this.setTextureOffset("Selection_Group.r2head", 0, 0);
        this.setTextureOffset("Selection_Group.r2body", 0, 14);
        this.setTextureOffset("Selection_Group.r2eye", 26, 3);
        this.r2rightleg = new ModelRenderer((ModelBase)this, 34, 11);
        this.r2rightleg.addBox(-1.0f, -3.0f, -1.4f, 1, 8, 3);
        this.r2rightleg.setRotationPoint(-4.066667f, 16.76667f, 0.0f);
        this.r2rightleg.setTextureSize(64, 32);
        this.setRotation(this.r2rightleg, 0.0f, 0.0f, 0.0f);
        this.r2rightfoot = new ModelRenderer((ModelBase)this, 40, 24);
        this.r2rightfoot.addBox(0.0f, 0.0f, 0.0f, 5, 3, 3);
        this.r2rightfoot.setRotationPoint(-6.0f, 20.96667f, 2.466667f);
        this.r2rightfoot.setTextureSize(64, 32);
        this.setRotation(this.r2rightfoot, 0.0f, 1.570796f, 0.0f);
        this.r2leftfoot = new ModelRenderer((ModelBase)this, 40, 24);
        this.r2leftfoot.addBox(0.0f, 0.0f, 0.0f, 5, 3, 3);
        this.r2leftfoot.setRotationPoint(6.0f, 21.0f, -2.533333f);
        this.r2leftfoot.setTextureSize(64, 32);
        this.setRotation(this.r2leftfoot, 0.0f, -1.570796f, 0.0f);
        this.r2leftleg = new ModelRenderer((ModelBase)this, 34, 11);
        this.r2leftleg.addBox(0.0f, -3.0f, -1.4f, 1, 8, 3);
        this.r2leftleg.setRotationPoint(4.1f, 16.83333f, 0.0f);
        this.r2leftleg.setTextureSize(64, 32);
        this.setRotation(this.r2leftleg, 0.0f, 0.0f, 0.0f);
        this.Selection_Group = new ModelRenderer((ModelBase)this, "Selection_Group");
        this.Selection_Group.setRotationPoint(0.0f, 13.5f, 0.0f);
        this.setRotation(this.Selection_Group, 0.0f, 0.0f, 0.0f);
        this.Selection_Group.addBox("r2head", -4.0f, -5.0f, -4.0f, 8, 5, 8);
        this.Selection_Group.addBox("r2body", -4.0f, 0.0f, -4.0f, 8, 7, 8);
        this.Selection_Group.addBox("r2eye", -1.0f, -4.5f, -4.5f, 2, 2, 1);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.r2rightleg.render(f5);
        this.r2rightfoot.render(f5);
        this.r2leftfoot.render(f5);
        this.r2leftleg.render(f5);
        this.Selection_Group.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

