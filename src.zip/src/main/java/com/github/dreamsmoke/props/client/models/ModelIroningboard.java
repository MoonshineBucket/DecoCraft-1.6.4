package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelIroningboard extends ModelInterface {
	
    ModelRenderer leg1;
    ModelRenderer leg2;
    ModelRenderer leg3;
    ModelRenderer leg4;
    ModelRenderer surface1;
    ModelRenderer surface2;
    ModelRenderer surface3;
    ModelRenderer support2;
    ModelRenderer support1;
    ModelRenderer support3;
    ModelRenderer support4;
    ModelRenderer ironhandle2;
    ModelRenderer iron3;
    ModelRenderer iron2;
    ModelRenderer ironhandle3;
    ModelRenderer iron1;

    public ModelIroningboard() {
        super(65);
        this.setTexture("ironingboard.png");
        this.textureWidth = 128;
        this.textureHeight = 64;
        this.leg1 = new ModelRenderer((ModelBase)this, 0, 25);
        this.leg1.addBox(0.0f, -15.0f, 0.0f, 1, 30, 1);
        this.leg1.setRotationPoint(5.0f, 16.0f, -7.0f);
        this.leg1.setTextureSize(128, 64);
        this.leg1.mirror = true;
        this.setRotation(this.leg1, 0.0f, 0.0f, 1.047198f);
        this.leg2 = new ModelRenderer((ModelBase)this, 0, 25);
        this.leg2.addBox(0.0f, -15.0f, 0.0f, 1, 30, 1);
        this.leg2.setRotationPoint(6.0f, 17.0f, -7.0f);
        this.leg2.setTextureSize(128, 64);
        this.leg2.mirror = true;
        this.setRotation(this.leg2, 0.0f, 0.0f, -1.047198f);
        this.leg3 = new ModelRenderer((ModelBase)this, 0, 25);
        this.leg3.addBox(0.0f, -15.0f, 0.0f, 1, 30, 1);
        this.leg3.setRotationPoint(5.0f, 16.0f, -1.0f);
        this.leg3.setTextureSize(128, 64);
        this.leg3.mirror = true;
        this.setRotation(this.leg3, 0.0f, 0.0f, 1.047198f);
        this.leg4 = new ModelRenderer((ModelBase)this, 0, 25);
        this.leg4.addBox(0.0f, -15.0f, 0.0f, 1, 30, 1);
        this.leg4.setRotationPoint(6.0f, 17.0f, -1.0f);
        this.leg4.setTextureSize(128, 64);
        this.leg4.mirror = true;
        this.setRotation(this.leg4, 0.0f, 0.0f, -1.047198f);
        this.surface1 = new ModelRenderer((ModelBase)this, 0, 0);
        this.surface1.addBox(-13.0f, 0.0f, 0.0f, 26, 1, 11);
        this.surface1.setRotationPoint(7.0f, 8.0f, -9.0f);
        this.surface1.setTextureSize(128, 64);
        this.surface1.mirror = true;
        this.setRotation(this.surface1, 0.0f, 0.0f, 0.0f);
        this.surface2 = new ModelRenderer((ModelBase)this, 0, 0);
        this.surface2.addBox(-13.0f, 0.0f, 0.0f, 2, 1, 9);
        this.surface2.setRotationPoint(5.0f, 8.0f, -8.0f);
        this.surface2.setTextureSize(128, 64);
        this.surface2.mirror = true;
        this.setRotation(this.surface2, 0.0f, 0.0f, 0.0f);
        this.surface3 = new ModelRenderer((ModelBase)this, 0, 0);
        this.surface3.addBox(-13.0f, 0.0f, 0.0f, 2, 1, 7);
        this.surface3.setRotationPoint(3.0f, 8.0f, -7.0f);
        this.surface3.setTextureSize(128, 64);
        this.surface3.mirror = true;
        this.setRotation(this.surface3, 0.0f, 0.0f, 0.0f);
        this.support2 = new ModelRenderer((ModelBase)this, 0, 25);
        this.support2.addBox(-0.5f, 0.0f, -3.5f, 1, 1, 7);
        this.support2.setRotationPoint(3.0f, 14.0f, -3.5f);
        this.support2.setTextureSize(128, 64);
        this.support2.mirror = true;
        this.setRotation(this.support2, 0.0f, 0.0f, 0.5235988f);
        this.support1 = new ModelRenderer((ModelBase)this, 0, 25);
        this.support1.addBox(-0.5f, 0.0f, -3.5f, 1, 1, 7);
        this.support1.setRotationPoint(-1.0f, 11.7f, -3.5f);
        this.support1.setTextureSize(128, 64);
        this.support1.mirror = true;
        this.setRotation(this.support1, 0.0f, 0.0f, 0.5235988f);
        this.support3 = new ModelRenderer((ModelBase)this, 0, 25);
        this.support3.addBox(-0.5f, 0.0f, -3.5f, 1, 1, 7);
        this.support3.setRotationPoint(9.0f, 13.6f, -3.5f);
        this.support3.setTextureSize(128, 64);
        this.support3.mirror = true;
        this.setRotation(this.support3, 0.0f, 0.0f, -0.5235988f);
        this.support4 = new ModelRenderer((ModelBase)this, 0, 25);
        this.support4.addBox(-0.5f, 0.0f, -3.5f, 1, 1, 7);
        this.support4.setRotationPoint(13.0f, 11.3f, -3.5f);
        this.support4.setTextureSize(128, 64);
        this.support4.mirror = true;
        this.setRotation(this.support4, 0.0f, 0.0f, -0.5235988f);
        this.ironhandle2 = new ModelRenderer((ModelBase)this, 40, 25);
        this.ironhandle2.addBox(-2.5f, 0.0f, -2.0f, 1, 3, 1);
        this.ironhandle2.setRotationPoint(15.5f, 4.0f, -2.5f);
        this.ironhandle2.setTextureSize(128, 64);
        this.ironhandle2.mirror = true;
        this.setRotation(this.ironhandle2, 0.0f, 0.0f, 0.0f);
        this.iron3 = new ModelRenderer((ModelBase)this, 40, 15);
        this.iron3.addBox(-2.5f, 0.0f, -2.0f, 1, 1, 1);
        this.iron3.setRotationPoint(15.5f, 7.0f, -4.5f);
        this.iron3.setTextureSize(128, 64);
        this.iron3.mirror = true;
        this.setRotation(this.iron3, 0.0f, 0.0f, 0.0f);
        this.iron2 = new ModelRenderer((ModelBase)this, 40, 15);
        this.iron2.addBox(-2.5f, 0.0f, -2.0f, 4, 1, 5);
        this.iron2.setRotationPoint(14.0f, 7.0f, -2.5f);
        this.iron2.setTextureSize(128, 64);
        this.iron2.mirror = true;
        this.setRotation(this.iron2, 0.0f, 0.0f, 0.0f);
        this.ironhandle3 = new ModelRenderer((ModelBase)this, 40, 31);
        this.ironhandle3.addBox(-2.5f, 0.0f, -2.0f, 1, 1, 3);
        this.ironhandle3.setRotationPoint(15.5f, 4.0f, -1.5f);
        this.ironhandle3.setTextureSize(128, 64);
        this.ironhandle3.mirror = true;
        this.setRotation(this.ironhandle3, 0.0f, 0.0f, 0.0f);
        this.iron1 = new ModelRenderer((ModelBase)this, 40, 15);
        this.iron1.addBox(-2.5f, 0.0f, -2.0f, 3, 1, 1);
        this.iron1.setRotationPoint(14.5f, 7.0f, -3.5f);
        this.iron1.setTextureSize(128, 64);
        this.iron1.mirror = true;
        this.setRotation(this.iron1, 0.0f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.leg1.render(f5);
        this.leg2.render(f5);
        this.leg3.render(f5);
        this.leg4.render(f5);
        this.surface1.render(f5);
        this.surface2.render(f5);
        this.surface3.render(f5);
        this.support2.render(f5);
        this.support1.render(f5);
        this.support3.render(f5);
        this.support4.render(f5);
        this.ironhandle2.render(f5);
        this.iron3.render(f5);
        this.iron2.render(f5);
        this.ironhandle3.render(f5);
        this.iron1.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

