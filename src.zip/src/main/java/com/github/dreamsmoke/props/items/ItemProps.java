package com.github.dreamsmoke.props.items;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;

import com.github.dreamsmoke.props.Props;
import com.github.dreamsmoke.props.data.ModelData;
import com.github.dreamsmoke.props.tabs.CreativeTabProps;
import com.github.dreamsmoke.props.tiles.TileProps;

import net.minecraft.block.Block;
import net.minecraft.block.StepSound;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.Icon;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class ItemProps extends Item {
	
    public Block block;
    public Icon[] icons = new Icon[Props.data.length];

    public ItemProps(Block block) {
        super(Props.itemID);
        this.block = block;
        this.setMaxDamage(0);
        this.setHasSubtypes(true);
        this.setCreativeTab((CreativeTabs)Props.Tab);
    }

    public boolean onItemUse(ItemStack itemStack, EntityPlayer entityPlayer, World world, int x, int y, int z, int par7, float par8, float par9, float par10) {
        if (itemStack.stackSize == 0) {
            return false;
        }
        
        if (par7 == 0) {
            --y;
        } else if (par7 == 1) {
            ++y;
        } else if (par7 == 2) {
            --z;
        } else if (par7 == 3) {
            ++z;
        } else if (par7 == 4) {
            --x;
        } else if (par7 == 5) {
            ++x;
        }
        
        if (!entityPlayer.canPlayerEdit(x, y, z, par7, itemStack)) {
            return false;
        }
        
        if (world.getBlockMaterial(x, y, z) != Material.air) {
        	entityPlayer.addChatMessage(EnumChatFormatting.RED + "\u041e\u0448\u0438\u0431\u043a\u0430" + EnumChatFormatting.DARK_GRAY + ": " + EnumChatFormatting.RED + "\u0417\u0434\u0435\u0441\u044c \u043d\u0435\u043b\u044c\u0437\u044f \u0440\u0430\u0437\u043c\u0435\u0441\u0442\u0438\u0442\u044c \u0431\u043b\u043e\u043a!");
        	return false;
        }
        
        int meta = itemStack.getItemDamage();
        if (!world.setBlock(x, y, z, this.block.blockID, 0, 3)) {
            return false;
        }
        
        int i1 = 0;
        i1 = MathHelper.floor_double((double)((double)(entityPlayer.rotationYaw * 16.0f / 360.0f) + 0.5)) & 0xF;
        TileEntity tileentity = world.getBlockTileEntity(x, y, z);
        if (tileentity != null && tileentity instanceof TileProps) {
            TileProps tile = (TileProps)tileentity;
            tile.rotation = i1;
            tile.type = meta;
        }
        
        world.playSoundEffect((double)((float)x + 0.5f), (double)((float)y + 0.5f), (double)((float)y + 0.5f), this.block.stepSound.getPlaceSound(), (this.block.stepSound.getVolume() + 1.0f) / 2.0f, this.block.stepSound.getPitch() * 0.8f);
        --itemStack.stackSize;
        return true;
    }

    public void getSubItems(int par1, CreativeTabs par2CreativeTabs, List par3List) {
        for (int j = 0; j < Props.data.length; ++j) {
            ModelData data = Props.data[j];
            if (data == null) continue;
            par3List.add(new ItemStack(par1, 1, data.type));
        }
    }

    public int getMetadata(int par1) {
        return par1;
    }

    public String getUnlocalizedName(ItemStack par1ItemStack) {
        ModelData model = Props.data[par1ItemStack.getItemDamage()];
        if (model != null) {
            return model.name;
        }
        return "";
    }

    @SideOnly(value=Side.CLIENT)
    public void registerIcons(IconRegister par1IconRegister) {
        for (int i = 0; i < Props.data.length; ++i) {
            ModelData model = Props.data[i];
            if (model == null) continue;
            this.icons[i] = par1IconRegister.registerIcon(model.name);
        }
    }

    public Icon getIconFromDamage(int par1) {
        return this.icons[par1];
    }
    
}

