package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelGoldingot extends ModelInterface {
	
    ModelRenderer bar1;
    ModelRenderer bar2;
    ModelRenderer bar3;
    ModelRenderer bar4;
    ModelRenderer bar5;
    ModelRenderer bar6;

    public ModelGoldingot(String texture, int type) {
        super(type);
        this.setTexture(texture);
        this.offsetInvY = -0.2f;
        this.textureWidth = 64;
        this.textureHeight = 32;
        this.bar1 = new ModelRenderer((ModelBase)this, 0, 0);
        this.bar1.addBox(0.0f, 0.0f, 0.0f, 4, 2, 14);
        this.bar1.setRotationPoint(3.0f, 22.0f, -7.0f);
        this.bar1.setTextureSize(64, 32);
        this.bar1.mirror = true;
        this.setRotation(this.bar1, 0.0f, 0.0f, 0.0f);
        this.bar2 = new ModelRenderer((ModelBase)this, 0, 0);
        this.bar2.addBox(0.0f, 0.0f, 0.0f, 4, 2, 14);
        this.bar2.setRotationPoint(-7.0f, 22.0f, -7.0f);
        this.bar2.setTextureSize(64, 32);
        this.bar2.mirror = true;
        this.setRotation(this.bar2, 0.0f, 0.0f, 0.0f);
        this.bar3 = new ModelRenderer((ModelBase)this, 0, 0);
        this.bar3.addBox(0.0f, 0.0f, 0.0f, 4, 2, 14);
        this.bar3.setRotationPoint(-2.0f, 22.0f, -7.0f);
        this.bar3.setTextureSize(64, 32);
        this.bar3.mirror = true;
        this.setRotation(this.bar3, 0.0f, 0.0f, 0.0f);
        this.bar4 = new ModelRenderer((ModelBase)this, 0, 0);
        this.bar4.addBox(0.0f, 0.0f, 0.0f, 4, 2, 14);
        this.bar4.setRotationPoint(1.0f, 20.0f, -7.0f);
        this.bar4.setTextureSize(64, 32);
        this.bar4.mirror = true;
        this.setRotation(this.bar4, 0.0f, 0.0f, 0.0f);
        this.bar5 = new ModelRenderer((ModelBase)this, 0, 0);
        this.bar5.addBox(0.0f, 0.0f, 0.0f, 4, 2, 14);
        this.bar5.setRotationPoint(-5.0f, 20.0f, -7.0f);
        this.bar5.setTextureSize(64, 32);
        this.bar5.mirror = true;
        this.setRotation(this.bar5, 0.0f, 0.0f, 0.0f);
        this.bar6 = new ModelRenderer((ModelBase)this, 0, 0);
        this.bar6.addBox(0.0f, 0.0f, 0.0f, 4, 2, 14);
        this.bar6.setRotationPoint(-2.0f, 17.93333f, -7.0f);
        this.bar6.setTextureSize(64, 32);
        this.bar6.mirror = true;
        this.setRotation(this.bar6, 0.0f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.bar1.render(f5);
        this.bar2.render(f5);
        this.bar3.render(f5);
        this.bar4.render(f5);
        this.bar5.render(f5);
        this.bar6.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

