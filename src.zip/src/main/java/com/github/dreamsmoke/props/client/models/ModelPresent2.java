package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelPresent2 extends ModelInterface {
	
    ModelRenderer Shape3;
    ModelRenderer Shape3lid;
    ModelRenderer bow3;
    ModelRenderer bow4;

    public ModelPresent2(String texture, int type) {
        super(type);
        this.setScale(0.4f);
        this.scaleItem = 1.1f;
        this.setTexture(texture);
        this.transparent = true;
        this.textureWidth = 256;
        this.textureHeight = 256;
        this.Shape3 = new ModelRenderer((ModelBase)this, 0, 46);
        this.Shape3.addBox(-8.0f, 0.0f, -8.0f, 16, 12, 16);
        this.Shape3.setRotationPoint(0.0f, 12.0f, 0.0f);
        this.Shape3.setTextureSize(256, 256);
        this.Shape3.mirror = true;
        this.setRotation(this.Shape3, 0.0f, 0.0f, 0.0f);
        this.Shape3lid = new ModelRenderer((ModelBase)this, 70, 46);
        this.Shape3lid.addBox(-8.0f, 0.0f, -8.0f, 18, 4, 18);
        this.Shape3lid.setRotationPoint(-1.0f, 8.0f, -1.0f);
        this.Shape3lid.setTextureSize(256, 256);
        this.Shape3lid.mirror = true;
        this.setRotation(this.Shape3lid, 0.0f, 0.0f, 0.0f);
        this.bow3 = new ModelRenderer((ModelBase)this, 160, 46);
        this.bow3.addBox(-5.5f, 0.0f, 1.0f, 13, 8, 0);
        this.bow3.setRotationPoint(-1.0f, 0.0f, -1.0f);
        this.bow3.setTextureSize(256, 256);
        this.bow3.mirror = true;
        this.setRotation(this.bow3, 0.0f, 0.0f, 0.0f);
        this.bow4 = new ModelRenderer((ModelBase)this, 160, 55);
        this.bow4.addBox(-1.0f, 0.0f, -5.5f, 0, 8, 13);
        this.bow4.setRotationPoint(1.0f, 0.0f, -1.0f);
        this.bow4.setTextureSize(256, 256);
        this.bow4.mirror = true;
        this.setRotation(this.bow4, 0.0f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.Shape3.render(f5);
        this.Shape3lid.render(f5);
        this.bow3.render(f5);
        this.bow4.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

