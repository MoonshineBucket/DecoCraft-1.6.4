package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelWoodblocks extends ModelInterface {
	
    ModelRenderer b1;
    ModelRenderer b2;
    ModelRenderer b3;
    ModelRenderer b5;
    ModelRenderer b4;
    ModelRenderer b6;

    public ModelWoodblocks() {
        super(3);
        this.setTexture("woodblocks.png");
        this.textureWidth = 32;
        this.textureHeight = 32;
        this.b1 = new ModelRenderer((ModelBase)this, 0, 0);
        this.b1.addBox(0.0f, 0.0f, 0.0f, 3, 3, 3);
        this.b1.setRotationPoint(-2.0f, 21.0f, 3.0f);
        this.b1.setTextureSize(32, 32);
        this.b1.mirror = true;
        this.setRotation(this.b1, 0.0f, 0.3490659f, 0.0f);
        this.b2 = new ModelRenderer((ModelBase)this, 12, 0);
        this.b2.addBox(-1.0f, 0.0f, 3.0f, 3, 3, 3);
        this.b2.setRotationPoint(4.0f, 21.0f, 0.0f);
        this.b2.setTextureSize(32, 32);
        this.b2.mirror = true;
        this.setRotation(this.b2, 0.0f, -0.1396263f, 0.0f);
        this.b3 = new ModelRenderer((ModelBase)this, 0, 6);
        this.b3.addBox(0.0f, 0.0f, 0.0f, 3, 3, 3);
        this.b3.setRotationPoint(0.0f, 18.0f, 1.0f);
        this.b3.setTextureSize(32, 32);
        this.b3.mirror = true;
        this.setRotation(this.b3, 0.0f, 0.0f, 0.0f);
        this.b5 = new ModelRenderer((ModelBase)this, 0, 12);
        this.b5.addBox(0.0f, 0.0f, 0.0f, 3, 3, 3);
        this.b5.setRotationPoint(-6.0f, 21.0f, -1.0f);
        this.b5.setTextureSize(32, 32);
        this.b5.mirror = true;
        this.setRotation(this.b5, 0.0f, -0.296706f, 0.0f);
        this.b4 = new ModelRenderer((ModelBase)this, 12, 6);
        this.b4.addBox(-1.0f, 0.0f, 0.0f, 3, 3, 3);
        this.b4.setRotationPoint(2.0f, 21.0f, -1.0f);
        this.b4.setTextureSize(32, 32);
        this.b4.mirror = true;
        this.setRotation(this.b4, 0.0f, 0.1745329f, 0.0f);
        this.b6 = new ModelRenderer((ModelBase)this, 12, 12);
        this.b6.addBox(0.0f, 0.0f, 0.0f, 3, 3, 3);
        this.b6.setRotationPoint(2.0f, 21.0f, -6.0f);
        this.b6.setTextureSize(32, 32);
        this.b6.mirror = true;
        this.setRotation(this.b6, 0.0f, 0.122173f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.b1.render(f5);
        this.b2.render(f5);
        this.b3.render(f5);
        this.b5.render(f5);
        this.b4.render(f5);
        this.b6.render(f5);
    }
}

