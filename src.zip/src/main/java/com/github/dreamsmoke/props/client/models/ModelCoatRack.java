package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelCoatRack extends ModelInterface {
	
    ModelRenderer c9;
    ModelRenderer c10;
    ModelRenderer c12;
    ModelRenderer c13;
    ModelRenderer c14;
    ModelRenderer coat;
    ModelRenderer Hat1;
    ModelRenderer Hat2;
    ModelRenderer c1;
    ModelRenderer c2;

    public ModelCoatRack() {
        super(221);
        this.setTexture("coatrack.png");
        this.textureWidth = 32;
        this.textureHeight = 64;
        this.c9 = new ModelRenderer((ModelBase)this, 0, 0);
        this.c9.addBox(-0.5f, -1.0f, -0.5f, 1, 23, 1);
        this.c9.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.c9.setTextureSize(32, 64);
        this.c9.mirror = true;
        this.setRotation(this.c9, 0.0f, -0.7853982f, 0.0f);
        this.c10 = new ModelRenderer((ModelBase)this, 0, 0);
        this.c10.addBox(-0.5f, -5.0f, 0.0f, 1, 5, 1);
        this.c10.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.c10.setTextureSize(32, 64);
        this.c10.mirror = true;
        this.setRotation(this.c10, 1.047198f, -0.7853982f, 0.0f);
        this.c12 = new ModelRenderer((ModelBase)this, 0, 0);
        this.c12.addBox(-0.5f, -5.0f, 0.0f, 1, 5, 1);
        this.c12.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.c12.setTextureSize(32, 64);
        this.c12.mirror = true;
        this.setRotation(this.c12, 1.047198f, 0.7853982f, 0.0f);
        this.c13 = new ModelRenderer((ModelBase)this, 0, 0);
        this.c13.addBox(-0.5f, -5.0f, 0.0f, 1, 5, 1);
        this.c13.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.c13.setTextureSize(32, 64);
        this.c13.mirror = true;
        this.setRotation(this.c13, 1.047198f, 2.356194f, 0.0f);
        this.c14 = new ModelRenderer((ModelBase)this, 0, 21);
        this.c14.addBox(-0.5f, -5.0f, 0.0f, 1, 5, 1);
        this.c14.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.c14.setTextureSize(32, 64);
        this.c14.mirror = true;
        this.setRotation(this.c14, 1.047198f, -2.356194f, 0.0f);
        this.coat = new ModelRenderer((ModelBase)this, 10, 0);
        this.coat.addBox(-0.5f, -1.0f, -4.0f, 0, 20, 8);
        this.coat.setRotationPoint(3.0f, -3.0f, 3.5f);
        this.coat.setTextureSize(32, 64);
        this.coat.mirror = true;
        this.setRotation(this.coat, 0.0f, -0.7853982f, 0.0f);
        this.Hat1 = new ModelRenderer((ModelBase)this, 0, 30);
        this.Hat1.addBox(-4.0f, -8.0f, -2.0f, 4, 6, 4);
        this.Hat1.setRotationPoint(0.0f, -2.0f, 0.0f);
        this.Hat1.setTextureSize(32, 64);
        this.Hat1.mirror = true;
        this.setRotation(this.Hat1, 0.6981317f, 0.0f, -1.01904f);
        this.Hat2 = new ModelRenderer((ModelBase)this, 0, 44);
        this.Hat2.addBox(-4.5f, -2.0f, -2.5f, 5, 1, 5);
        this.Hat2.setRotationPoint(0.0f, -2.0f, 0.0f);
        this.Hat2.setTextureSize(32, 64);
        this.Hat2.mirror = true;
        this.setRotation(this.Hat2, 0.6981317f, 0.0f, -1.01904f);
        this.c1 = new ModelRenderer((ModelBase)this, 0, 0);
        this.c1.addBox(-2.0f, -1.0f, -2.0f, 4, 1, 4);
        this.c1.setRotationPoint(0.0f, 23.0f, 0.0f);
        this.c1.setTextureSize(32, 64);
        this.c1.mirror = true;
        this.setRotation(this.c1, 0.0f, 0.0f, 0.0f);
        this.c2 = new ModelRenderer((ModelBase)this, 0, 0);
        this.c2.addBox(-2.5f, -1.0f, -2.5f, 5, 1, 5);
        this.c2.setRotationPoint(0.0f, 24.0f, 0.0f);
        this.c2.setTextureSize(32, 64);
        this.c2.mirror = true;
        this.setRotation(this.c2, 0.0f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.c9.render(f5);
        this.c10.render(f5);
        this.c12.render(f5);
        this.c13.render(f5);
        this.c14.render(f5);
        this.coat.render(f5);
        this.Hat1.render(f5);
        this.Hat2.render(f5);
        this.c1.render(f5);
        this.c2.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

