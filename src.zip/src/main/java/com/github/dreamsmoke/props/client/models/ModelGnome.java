package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelGnome extends ModelInterface {
	
    ModelRenderer Body;
    ModelRenderer Leg1;
    ModelRenderer Leg2;
    ModelRenderer Arm1;
    ModelRenderer Arm2;
    ModelRenderer Head;
    ModelRenderer Hat0;
    ModelRenderer Hat1;
    ModelRenderer Hat2;
    ModelRenderer Hat3;
    ModelRenderer Hat4;

    public ModelGnome() {
        super(119);
        this.setTexture("Gnometexture.png");
        this.setScale(0.5f);
        this.textureWidth = 64;
        this.textureHeight = 32;
        this.Body = new ModelRenderer((ModelBase)this, 0, 0);
        this.Body.addBox(0.0f, 0.0f, 0.0f, 7, 12, 7);
        this.Body.setRotationPoint(-3.5f, 7.0f, -3.0f);
        this.Body.setTextureSize(64, 32);
        this.Body.mirror = true;
        this.setRotation(this.Body, 0.0f, 0.0f, 0.0f);
        this.Leg1 = new ModelRenderer((ModelBase)this, 0, 22);
        this.Leg1.addBox(0.0f, 0.0f, 0.0f, 3, 5, 3);
        this.Leg1.setRotationPoint(-3.5f, 19.0f, -1.0f);
        this.Leg1.setTextureSize(64, 32);
        this.Leg1.mirror = true;
        this.setRotation(this.Leg1, 0.0f, 0.0f, 0.0f);
        this.Leg2 = new ModelRenderer((ModelBase)this, 0, 22);
        this.Leg2.addBox(0.0f, 0.0f, 0.0f, 3, 5, 3);
        this.Leg2.setRotationPoint(0.5f, 19.0f, -1.0f);
        this.Leg2.setTextureSize(64, 32);
        this.Leg2.mirror = true;
        this.setRotation(this.Leg2, 0.0f, 0.0f, 0.0f);
        this.Arm1 = new ModelRenderer((ModelBase)this, 54, 19);
        this.Arm1.addBox(-2.0f, 0.0f, -1.0f, 2, 10, 3);
        this.Arm1.setRotationPoint(-3.5f, 7.0f, 0.0f);
        this.Arm1.setTextureSize(64, 32);
        this.Arm1.mirror = true;
        this.setRotation(this.Arm1, 0.0f, 0.0f, 0.0f);
        this.Arm2 = new ModelRenderer((ModelBase)this, 54, 19);
        this.Arm2.addBox(0.0f, 0.0f, 0.0f, 2, 10, 3);
        this.Arm2.setRotationPoint(3.5f, 7.0f, -1.0f);
        this.Arm2.setTextureSize(64, 32);
        this.Arm2.mirror = true;
        this.setRotation(this.Arm2, 0.0f, 0.0f, 0.0f);
        this.Head = new ModelRenderer((ModelBase)this, 28, 0);
        this.Head.addBox(0.0f, 0.0f, 0.0f, 9, 8, 9);
        this.Head.setRotationPoint(-4.5f, -1.0f, -4.0f);
        this.Head.setTextureSize(64, 32);
        this.Head.mirror = true;
        this.setRotation(this.Head, 0.0f, 0.0f, 0.0f);
        this.Hat0 = new ModelRenderer((ModelBase)this, 15, 22);
        this.Hat0.addBox(0.0f, 0.0f, 0.0f, 9, 1, 9);
        this.Hat0.setRotationPoint(-4.5f, -2.0f, -4.0f);
        this.Hat0.setTextureSize(64, 32);
        this.Hat0.mirror = true;
        this.setRotation(this.Hat0, 0.0f, 0.0f, 0.0f);
        this.Hat1 = new ModelRenderer((ModelBase)this, 18, 23);
        this.Hat1.addBox(0.0f, 0.0f, 0.0f, 7, 1, 7);
        this.Hat1.setRotationPoint(-3.5f, -3.0f, -3.0f);
        this.Hat1.setTextureSize(64, 32);
        this.Hat1.mirror = true;
        this.setRotation(this.Hat1, 0.0f, 0.0f, 0.0f);
        this.Hat2 = new ModelRenderer((ModelBase)this, 22, 24);
        this.Hat2.addBox(0.0f, 0.0f, 0.0f, 6, 1, 6);
        this.Hat2.setRotationPoint(-2.5f, -4.0f, -2.0f);
        this.Hat2.setTextureSize(64, 32);
        this.Hat2.mirror = true;
        this.setRotation(this.Hat2, 0.0f, 0.0f, 0.0f);
        this.Hat3 = new ModelRenderer((ModelBase)this, 26, 27);
        this.Hat3.addBox(0.0f, 0.0f, 0.0f, 3, 1, 3);
        this.Hat3.setRotationPoint(-0.5f, -5.0f, -1.0f);
        this.Hat3.setTextureSize(64, 32);
        this.Hat3.mirror = true;
        this.setRotation(this.Hat3, 0.0f, 0.0f, 0.0f);
        this.Hat4 = new ModelRenderer((ModelBase)this, 15, 25);
        this.Hat4.addBox(5.0f, 0.0f, 0.0f, 2, 1, 2);
        this.Hat4.setRotationPoint(-4.5f, -6.0f, 0.0f);
        this.Hat4.setTextureSize(64, 32);
        this.Hat4.mirror = true;
        this.setRotation(this.Hat4, 0.0f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.Body.render(f5);
        this.Leg1.render(f5);
        this.Leg2.render(f5);
        this.Arm1.render(f5);
        this.Arm2.render(f5);
        this.Head.render(f5);
        this.Hat0.render(f5);
        this.Hat1.render(f5);
        this.Hat2.render(f5);
        this.Hat3.render(f5);
        this.Hat4.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

