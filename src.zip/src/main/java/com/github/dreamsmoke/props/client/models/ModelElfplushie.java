package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelElfplushie extends ModelInterface {
	
    ModelRenderer arm1;
    ModelRenderer body;
    ModelRenderer leg1;
    ModelRenderer head;
    ModelRenderer arm2;
    ModelRenderer leg2;
    ModelRenderer hat1;
    ModelRenderer hat2;
    ModelRenderer hat3;
    ModelRenderer hat4;
    ModelRenderer hat5;
    ModelRenderer hat6;
    ModelRenderer ear1;
    ModelRenderer ear2;

    public ModelElfplushie() {
        super(155);
        this.setTexture("elfplushie.png");
        this.setScale(0.5f);
        this.scaleItem = 2.0f;
        this.transparent = true;
        this.textureWidth = 128;
        this.textureHeight = 64;
        this.arm1 = new ModelRenderer((ModelBase)this, 0, 16);
        this.arm1.addBox(-1.5f, 10.0f, 1.5f, 2, 4, 2);
        this.arm1.setRotationPoint(0.0f, 8.0f, 0.0f);
        this.arm1.setTextureSize(128, 64);
        this.arm1.mirror = true;
        this.setRotation(this.arm1, 0.0f, 1.570796f, 0.0f);
        this.body = new ModelRenderer((ModelBase)this, 32, 1);
        this.body.addBox(-1.5f, 10.0f, -1.5f, 2, 4, 3);
        this.body.setRotationPoint(0.0f, 8.0f, 0.0f);
        this.body.setTextureSize(128, 64);
        this.body.mirror = true;
        this.setRotation(this.body, 0.0f, 1.570796f, 0.0f);
        this.leg1 = new ModelRenderer((ModelBase)this, 32, 8);
        this.leg1.addBox(-1.0f, 10.0f, 0.0f, 4, 2, 2);
        this.leg1.setRotationPoint(0.0f, 12.0f, 0.0f);
        this.leg1.setTextureSize(128, 64);
        this.leg1.mirror = true;
        this.setRotation(this.leg1, -0.0174533f, 1.396263f, 0.0f);
        this.head = new ModelRenderer((ModelBase)this, 0, 0);
        this.head.addBox(-4.0f, 2.0f, -3.5f, 8, 8, 8);
        this.head.setRotationPoint(0.0f, 8.0f, 0.0f);
        this.head.setTextureSize(128, 64);
        this.head.mirror = true;
        this.setRotation(this.head, 0.0f, 0.0f, 0.0f);
        this.arm2 = new ModelRenderer((ModelBase)this, 0, 16);
        this.arm2.addBox(-1.5f, 10.0f, -3.5f, 2, 4, 2);
        this.arm2.setRotationPoint(0.0f, 8.0f, 0.0f);
        this.arm2.setTextureSize(128, 64);
        this.arm2.mirror = true;
        this.setRotation(this.arm2, 0.0f, 1.570796f, 0.0f);
        this.leg2 = new ModelRenderer((ModelBase)this, 32, 8);
        this.leg2.addBox(-1.0f, 10.0f, -2.0f, 4, 2, 2);
        this.leg2.setRotationPoint(0.0f, 12.0f, 0.0f);
        this.leg2.setTextureSize(128, 64);
        this.leg2.mirror = true;
        this.setRotation(this.leg2, 0.0f, 1.745329f, 0.0f);
        this.hat1 = new ModelRenderer((ModelBase)this, 26, 28);
        this.hat1.addBox(-2.0f, 2.0f, -1.5f, 1, 1, 1);
        this.hat1.setRotationPoint(4.5f, -2.3f, 4.5f);
        this.hat1.setTextureSize(128, 64);
        this.hat1.mirror = true;
        this.setRotation(this.hat1, 0.0f, 0.0f, 0.1047198f);
        this.hat2 = new ModelRenderer((ModelBase)this, 50, 50);
        this.hat2.addBox(-4.0f, 2.0f, -3.5f, 10, 2, 10);
        this.hat2.setRotationPoint(-1.0f, 6.0f, -1.0f);
        this.hat2.setTextureSize(128, 64);
        this.hat2.mirror = true;
        this.setRotation(this.hat2, 0.0f, 0.0f, 0.0f);
        this.hat3 = new ModelRenderer((ModelBase)this, 13, 52);
        this.hat3.addBox(-4.0f, 2.0f, -3.5f, 8, 2, 8);
        this.hat3.setRotationPoint(0.0f, 4.0f, 0.0f);
        this.hat3.setTextureSize(128, 64);
        this.hat3.mirror = true;
        this.setRotation(this.hat3, 0.0f, 0.0f, 0.0349066f);
        this.hat4 = new ModelRenderer((ModelBase)this, 19, 43);
        this.hat4.addBox(-4.0f, 2.0f, -3.5f, 5, 2, 5);
        this.hat4.setRotationPoint(2.0f, 2.2f, 2.0f);
        this.hat4.setTextureSize(128, 64);
        this.hat4.mirror = true;
        this.setRotation(this.hat4, 0.0f, 0.0f, 0.0523599f);
        this.hat5 = new ModelRenderer((ModelBase)this, 23, 36);
        this.hat5.addBox(-2.0f, 2.0f, -1.5f, 3, 2, 3);
        this.hat5.setRotationPoint(1.0f, 0.3f, 2.0f);
        this.hat5.setTextureSize(128, 64);
        this.hat5.mirror = true;
        this.setRotation(this.hat5, 0.0f, 0.0f, 0.0523599f);
        this.hat6 = new ModelRenderer((ModelBase)this, 25, 31);
        this.hat6.addBox(-2.0f, 2.0f, -1.5f, 2, 2, 2);
        this.hat6.setRotationPoint(3.0f, -1.5f, 3.0f);
        this.hat6.setTextureSize(128, 64);
        this.hat6.mirror = true;
        this.setRotation(this.hat6, 0.0f, 0.0f, 0.1047198f);
        this.ear1 = new ModelRenderer((ModelBase)this, 49, 24);
        this.ear1.addBox(0.0f, 0.0f, 0.0f, 4, 7, 0);
        this.ear1.setRotationPoint(4.0f, 9.0f, 0.0f);
        this.ear1.setTextureSize(128, 64);
        this.ear1.mirror = true;
        this.setRotation(this.ear1, 0.0f, 0.0f, 0.0f);
        this.ear2 = new ModelRenderer((ModelBase)this, 41, 24);
        this.ear2.addBox(0.0f, 0.0f, 0.0f, 4, 7, 0);
        this.ear2.setRotationPoint(-8.0f, 9.0f, 0.0f);
        this.ear2.setTextureSize(128, 64);
        this.ear2.mirror = true;
        this.setRotation(this.ear2, 0.0f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.arm1.render(f5);
        this.body.render(f5);
        this.leg1.render(f5);
        this.head.render(f5);
        this.arm2.render(f5);
        this.leg2.render(f5);
        this.hat1.render(f5);
        this.hat2.render(f5);
        this.hat3.render(f5);
        this.hat4.render(f5);
        this.hat5.render(f5);
        this.hat6.render(f5);
        this.ear1.render(f5);
        this.ear2.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

