package com.github.dreamsmoke.props.tiles;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.INetworkManager;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.Packet132TileEntityData;
import net.minecraft.tileentity.TileEntity;

public class TileProps extends TileEntity {
	
    public int type = 0;
    public int rotation;

    public void readFromNBT(NBTTagCompound compound) {
        super.readFromNBT(compound);
        this.type = compound.getInteger("BlockType");
        this.rotation = compound.getInteger("BlockRotation");
    }

    public void writeToNBT(NBTTagCompound compound) {
        super.writeToNBT(compound);
        compound.setInteger("BlockType", this.type);
        compound.setInteger("BlockRotation", this.rotation);
    }

    public Packet getDescriptionPacket() {
        NBTTagCompound nbttagcompound = new NBTTagCompound();
        this.writeToNBT(nbttagcompound);
        return new Packet132TileEntityData(this.xCoord, this.yCoord, this.zCoord, -1, nbttagcompound);
    }

    public void onDataPacket(INetworkManager net, Packet132TileEntityData pkt) {
        this.readFromNBT(pkt.data);
    }
    
}

