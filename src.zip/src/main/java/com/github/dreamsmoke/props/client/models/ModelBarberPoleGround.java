package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelBarberPoleGround extends ModelInterface {
	
    ModelRenderer p6;
    ModelRenderer p1;
    ModelRenderer p2;
    ModelRenderer p3;
    ModelRenderer p4;
    ModelRenderer p5;

    public ModelBarberPoleGround() {
        super(186);
        this.setTexture("barberpole.png");
        this.transparent = true;
        this.textureWidth = 44;
        this.textureHeight = 18;
        this.p6 = new ModelRenderer((ModelBase)this, 0, 4);
        this.p6.addBox(-2.0f, 11.0f, -2.0f, 4, 10, 4);
        this.p6.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.p6.setTextureSize(44, 18);
        this.p6.mirror = true;
        this.setRotation(this.p6, 0.0f, 0.0f, 0.0f);
        this.p1 = new ModelRenderer((ModelBase)this, 0, 0);
        this.p1.addBox(-2.0f, 23.0f, -2.0f, 4, 1, 4);
        this.p1.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.p1.setTextureSize(44, 18);
        this.p1.mirror = true;
        this.setRotation(this.p1, 0.0f, 0.0f, 0.0f);
        this.p2 = new ModelRenderer((ModelBase)this, 0, 0);
        this.p2.addBox(-3.0f, 21.0f, -3.0f, 6, 2, 6);
        this.p2.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.p2.setTextureSize(44, 18);
        this.p2.mirror = true;
        this.setRotation(this.p2, 0.0f, 0.0f, 0.0f);
        this.p3 = new ModelRenderer((ModelBase)this, 24, -5);
        this.p3.addBox(-2.5f, 1.0f, -2.5f, 5, 10, 5);
        this.p3.setRotationPoint(0.0f, 10.0f, 0.0f);
        this.p3.setTextureSize(44, 18);
        this.p3.mirror = true;
        this.setRotation(this.p3, 0.0f, 0.0f, 0.0f);
        this.p4 = new ModelRenderer((ModelBase)this, 0, 0);
        this.p4.addBox(-3.0f, 9.0f, -3.0f, 6, 2, 6);
        this.p4.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.p4.setTextureSize(44, 18);
        this.p4.mirror = true;
        this.setRotation(this.p4, 0.0f, 0.0f, 0.0f);
        this.p5 = new ModelRenderer((ModelBase)this, 0, 0);
        this.p5.addBox(-2.0f, 8.0f, -2.0f, 4, 1, 4);
        this.p5.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.p5.setTextureSize(44, 18);
        this.p5.mirror = true;
        this.setRotation(this.p5, 0.0f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.p6.render(f5);
        this.p1.render(f5);
        this.p2.render(f5);
        this.p3.render(f5);
        this.p4.render(f5);
        this.p5.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

