package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelXylophone extends ModelInterface {
	
    ModelRenderer red;
    ModelRenderer orange;
    ModelRenderer yellow;
    ModelRenderer green;
    ModelRenderer blue;
    ModelRenderer purple;
    ModelRenderer wood1;
    ModelRenderer wood2;
    ModelRenderer stick;
    ModelRenderer Shape1;

    public ModelXylophone() {
        super(34);
        this.setTexture("xylophone.png");
        this.setScale(0.8f);
        this.scaleItem = 1.0f;
        this.offsetInvY = 0.0f;
        this.textureWidth = 64;
        this.textureHeight = 32;
        this.red = new ModelRenderer((ModelBase)this, 0, 26);
        this.red.addBox(0.0f, 0.0f, 0.0f, 2, 1, 5);
        this.red.setRotationPoint(6.0f, 21.0f, -2.0f);
        this.red.setTextureSize(64, 32);
        this.red.mirror = true;
        this.setRotation(this.red, 0.0f, 0.0f, 0.0f);
        this.orange = new ModelRenderer((ModelBase)this, 0, 19);
        this.orange.addBox(0.0f, 0.0f, 0.0f, 2, 1, 6);
        this.orange.setRotationPoint(3.0f, 21.0f, -2.5f);
        this.orange.setTextureSize(64, 32);
        this.orange.mirror = true;
        this.setRotation(this.orange, 0.0f, 0.0f, 0.0f);
        this.yellow = new ModelRenderer((ModelBase)this, 0, 11);
        this.yellow.addBox(0.0f, 0.0f, 0.0f, 2, 1, 7);
        this.yellow.setRotationPoint(0.0f, 21.0f, -3.0f);
        this.yellow.setTextureSize(64, 32);
        this.yellow.mirror = true;
        this.setRotation(this.yellow, 0.0f, 0.0f, 0.0f);
        this.green = new ModelRenderer((ModelBase)this, 44, 2);
        this.green.addBox(0.0f, 0.0f, 0.0f, 2, 1, 8);
        this.green.setRotationPoint(-3.0f, 21.0f, -3.5f);
        this.green.setTextureSize(64, 32);
        this.green.mirror = true;
        this.setRotation(this.green, 0.0f, 0.0f, 0.0f);
        this.blue = new ModelRenderer((ModelBase)this, 42, 11);
        this.blue.addBox(0.0f, 0.0f, 0.0f, 2, 1, 9);
        this.blue.setRotationPoint(-6.0f, 21.0f, -4.0f);
        this.blue.setTextureSize(64, 32);
        this.blue.mirror = true;
        this.setRotation(this.blue, 0.0f, 0.0f, 0.0f);
        this.purple = new ModelRenderer((ModelBase)this, 40, 21);
        this.purple.addBox(0.0f, 0.0f, 0.0f, 2, 1, 10);
        this.purple.setRotationPoint(-9.0f, 21.0f, -4.5f);
        this.purple.setTextureSize(64, 32);
        this.purple.mirror = true;
        this.setRotation(this.purple, 0.0f, 0.0f, 0.0f);
        this.wood1 = new ModelRenderer((ModelBase)this, 0, 0);
        this.wood1.addBox(-18.5f, 0.0f, -0.5f, 20, 2, 1);
        this.wood1.setRotationPoint(8.0f, 22.0f, 2.0f);
        this.wood1.setTextureSize(64, 32);
        this.wood1.mirror = true;
        this.setRotation(this.wood1, 0.0f, 0.0872665f, 0.0f);
        this.wood2 = new ModelRenderer((ModelBase)this, 0, 0);
        this.wood2.addBox(-18.5f, 0.0f, -0.5f, 20, 2, 1);
        this.wood2.setRotationPoint(8.0f, 22.0f, -1.0f);
        this.wood2.setTextureSize(64, 32);
        this.wood2.mirror = true;
        this.setRotation(this.wood2, 0.0f, -0.0872665f, 0.0f);
        this.stick = new ModelRenderer((ModelBase)this, 0, 5);
        this.stick.addBox(-9.0f, -1.0f, -1.0f, 9, 1, 1);
        this.stick.setRotationPoint(6.5f, 24.0f, -5.5f);
        this.stick.setTextureSize(64, 32);
        this.stick.mirror = true;
        this.setRotation(this.stick, 0.0f, 0.0f, 0.0523599f);
        this.Shape1 = new ModelRenderer((ModelBase)this, 32, 28);
        this.Shape1.addBox(0.0f, 0.0f, 0.0f, 2, 2, 2);
        this.Shape1.setRotationPoint(-3.0f, 22.0f, -7.0f);
        this.Shape1.setTextureSize(64, 32);
        this.Shape1.mirror = true;
        this.setRotation(this.Shape1, 0.0f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.red.render(f5);
        this.orange.render(f5);
        this.yellow.render(f5);
        this.green.render(f5);
        this.blue.render(f5);
        this.purple.render(f5);
        this.wood1.render(f5);
        this.wood2.render(f5);
        this.stick.render(f5);
        this.Shape1.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

