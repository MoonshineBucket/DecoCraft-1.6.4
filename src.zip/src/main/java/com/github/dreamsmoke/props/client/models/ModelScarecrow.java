package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelScarecrow extends ModelInterface {
	
    ModelRenderer leg;
    ModelRenderer leftarm2;
    ModelRenderer rightarm2;
    ModelRenderer hat2;
    ModelRenderer Hat1;
    ModelRenderer head;
    ModelRenderer body;
    ModelRenderer rightarm;
    ModelRenderer leftarm;

    public ModelScarecrow() {
        super(37);
        this.setTexture("scarecrow.png");
        this.scaleItem = 0.8f;
        this.offsetInvY = 0.5f;
        this.transparent = true;
        this.textureWidth = 128;
        this.textureHeight = 64;
        this.leg = new ModelRenderer((ModelBase)this, 1, 36);
        this.leg.addBox(-2.0f, 0.0f, -2.0f, 2, 25, 2);
        this.leg.setRotationPoint(1.0f, -1.0f, 1.0f);
        this.leg.setTextureSize(128, 64);
        this.leg.mirror = true;
        this.setRotation(this.leg, 0.0f, 0.0f, 0.0f);
        this.leftarm2 = new ModelRenderer((ModelBase)this, 77, 16);
        this.leftarm2.addBox(-3.0f, -2.0f, -2.0f, 4, 5, 4);
        this.leftarm2.setRotationPoint(-5.0f, 2.0f, 0.0f);
        this.leftarm2.setTextureSize(128, 64);
        this.leftarm2.mirror = true;
        this.setRotation(this.leftarm2, 0.0f, 0.0f, 0.0f);
        this.rightarm2 = new ModelRenderer((ModelBase)this, 54, 16);
        this.rightarm2.addBox(-3.0f, -2.0f, -2.0f, 4, 5, 4);
        this.rightarm2.setRotationPoint(7.0f, 2.0f, 0.0f);
        this.rightarm2.setTextureSize(128, 64);
        this.rightarm2.mirror = true;
        this.setRotation(this.rightarm2, 0.0f, 0.0f, 0.0f);
        this.hat2 = new ModelRenderer((ModelBase)this, 89, 0);
        this.hat2.addBox(-4.0f, -8.0f, -4.0f, 6, 4, 6);
        this.hat2.setRotationPoint(1.0f, -6.0f, 1.0f);
        this.hat2.setTextureSize(128, 64);
        this.hat2.mirror = true;
        this.setRotation(this.hat2, 0.0f, 0.0f, 0.0f);
        this.Hat1 = new ModelRenderer((ModelBase)this, 40, 0);
        this.Hat1.addBox(-4.0f, -8.0f, -4.0f, 12, 1, 12);
        this.Hat1.setRotationPoint(-2.0f, -2.0f, -2.0f);
        this.Hat1.setTextureSize(128, 64);
        this.Hat1.mirror = true;
        this.setRotation(this.Hat1, 0.0f, 0.0f, 0.0f);
        this.head = new ModelRenderer((ModelBase)this, 0, 0);
        this.head.addBox(-4.0f, -8.0f, -4.0f, 8, 8, 8);
        this.head.setRotationPoint(0.0f, -1.0f, 0.0f);
        this.head.setTextureSize(128, 64);
        this.head.mirror = true;
        this.setRotation(this.head, 0.0f, 0.0f, 0.0f);
        this.body = new ModelRenderer((ModelBase)this, 16, 18);
        this.body.addBox(-4.0f, 0.0f, -2.0f, 8, 12, 4);
        this.body.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.body.setTextureSize(128, 64);
        this.body.mirror = true;
        this.setRotation(this.body, 0.0f, 0.0f, 0.0f);
        this.rightarm = new ModelRenderer((ModelBase)this, 40, 43);
        this.rightarm.addBox(-3.0f, -2.0f, -2.0f, 12, 2, 2);
        this.rightarm.setRotationPoint(-10.0f, 2.1f, 1.0f);
        this.rightarm.setTextureSize(128, 64);
        this.rightarm.mirror = true;
        this.setRotation(this.rightarm, 0.0f, 0.0f, 0.0f);
        this.leftarm = new ModelRenderer((ModelBase)this, 40, 43);
        this.leftarm.addBox(-3.0f, -2.0f, -2.0f, 12, 2, 2);
        this.leftarm.setRotationPoint(4.0f, 2.1f, 1.0f);
        this.leftarm.setTextureSize(128, 64);
        this.leftarm.mirror = true;
        this.setRotation(this.leftarm, 0.0f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.leg.render(f5);
        this.leftarm2.render(f5);
        this.rightarm2.render(f5);
        this.hat2.render(f5);
        this.Hat1.render(f5);
        this.head.render(f5);
        this.body.render(f5);
        this.rightarm.render(f5);
        this.leftarm.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

