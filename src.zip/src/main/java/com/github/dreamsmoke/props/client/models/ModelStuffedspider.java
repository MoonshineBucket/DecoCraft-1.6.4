package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelStuffedspider extends ModelInterface {
	
    ModelRenderer Head;
    ModelRenderer Body;
    ModelRenderer RearEnd;
    ModelRenderer Leg8;
    ModelRenderer Leg6;
    ModelRenderer Leg4;
    ModelRenderer Leg2;
    ModelRenderer Leg7;
    ModelRenderer Leg5;
    ModelRenderer Leg3;
    ModelRenderer Leg1;

    public ModelStuffedspider() {
        super(98);
        this.setTexture("stuffedspiderpurple.png");
        this.setScale(0.6f);
        this.scaleItem = 1.7f;
        this.textureWidth = 64;
        this.textureHeight = 32;
        this.Head = new ModelRenderer((ModelBase)this, 32, 4);
        this.Head.addBox(-4.0f, -4.0f, -8.0f, 4, 4, 4);
        this.Head.setRotationPoint(2.0f, 23.0f, 0.0f);
        this.Head.setTextureSize(64, 32);
        this.Head.mirror = true;
        this.setRotation(this.Head, 0.0f, 0.0f, 0.0f);
        this.Body = new ModelRenderer((ModelBase)this, 0, 0);
        this.Body.addBox(-3.0f, -3.0f, -3.0f, 3, 3, 3);
        this.Body.setRotationPoint(1.5f, 22.5f, -2.0f);
        this.Body.setTextureSize(64, 32);
        this.Body.mirror = true;
        this.setRotation(this.Body, 0.0f, 0.0f, 0.0f);
        this.RearEnd = new ModelRenderer((ModelBase)this, 0, 12);
        this.RearEnd.addBox(-5.0f, -4.0f, -6.0f, 5, 4, 6);
        this.RearEnd.setRotationPoint(2.5f, 23.0f, 4.0f);
        this.RearEnd.setTextureSize(64, 32);
        this.RearEnd.mirror = true;
        this.setRotation(this.RearEnd, 0.0f, 0.0f, 0.0f);
        this.Leg8 = new ModelRenderer((ModelBase)this, 18, 0);
        this.Leg8.addBox(0.0f, 0.0f, 0.0f, 8, 1, 1);
        this.Leg8.setRotationPoint(2.0f, 22.0f, -2.0f);
        this.Leg8.setTextureSize(64, 32);
        this.Leg8.mirror = true;
        this.setRotation(this.Leg8, 0.0f, 0.5759587f, 0.1919862f);
        this.Leg6 = new ModelRenderer((ModelBase)this, 18, 0);
        this.Leg6.addBox(-1.0f, -1.0f, -1.0f, 8, 1, 1);
        this.Leg6.setRotationPoint(3.0f, 23.0f, 0.0f);
        this.Leg6.setTextureSize(64, 32);
        this.Leg6.mirror = true;
        this.setRotation(this.Leg6, 0.0f, 0.2792527f, 0.1919862f);
        this.Leg4 = new ModelRenderer((ModelBase)this, 18, 0);
        this.Leg4.addBox(-1.0f, -1.0f, -1.0f, 8, 1, 1);
        this.Leg4.setRotationPoint(2.0f, 23.0f, 1.0f);
        this.Leg4.setTextureSize(64, 32);
        this.Leg4.mirror = true;
        this.setRotation(this.Leg4, 0.0f, -0.2792527f, 0.1919862f);
        this.Leg2 = new ModelRenderer((ModelBase)this, 18, 0);
        this.Leg2.addBox(-1.0f, -1.0f, -1.0f, 8, 1, 1);
        this.Leg2.setRotationPoint(2.0f, 23.0f, 2.0f);
        this.Leg2.setTextureSize(64, 32);
        this.Leg2.mirror = true;
        this.setRotation(this.Leg2, 0.0f, -0.5759587f, 0.1919862f);
        this.Leg7 = new ModelRenderer((ModelBase)this, 18, 0);
        this.Leg7.addBox(0.0f, 0.0f, 0.0f, 8, 1, 1);
        this.Leg7.setRotationPoint(-8.0f, 23.0f, -6.0f);
        this.Leg7.setTextureSize(64, 32);
        this.Leg7.mirror = true;
        this.setRotation(this.Leg7, 0.0f, -0.5759587f, -0.1919862f);
        this.Leg5 = new ModelRenderer((ModelBase)this, 18, 0);
        this.Leg5.addBox(0.0f, 0.0f, 0.0f, 8, 1, 1);
        this.Leg5.setRotationPoint(-9.0f, 23.0f, -3.0f);
        this.Leg5.setTextureSize(64, 32);
        this.Leg5.mirror = true;
        this.setRotation(this.Leg5, 0.0f, -0.2792527f, -0.1919862f);
        this.Leg3 = new ModelRenderer((ModelBase)this, 18, 0);
        this.Leg3.addBox(0.0f, 0.0f, 0.0f, 8, 1, 1);
        this.Leg3.setRotationPoint(-10.0f, 23.0f, 2.0f);
        this.Leg3.setTextureSize(64, 32);
        this.Leg3.mirror = true;
        this.setRotation(this.Leg3, 0.0f, 0.2792527f, -0.1919862f);
        this.Leg1 = new ModelRenderer((ModelBase)this, 18, 0);
        this.Leg1.addBox(0.0f, 0.0f, 1.0f, 8, 1, 1);
        this.Leg1.setRotationPoint(-9.0f, 23.0f, 5.0f);
        this.Leg1.setTextureSize(64, 32);
        this.Leg1.mirror = true;
        this.setRotation(this.Leg1, 0.0f, 0.5759587f, -0.1919862f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.Head.render(f5);
        this.Body.render(f5);
        this.RearEnd.render(f5);
        this.Leg8.render(f5);
        this.Leg6.render(f5);
        this.Leg4.render(f5);
        this.Leg2.render(f5);
        this.Leg7.render(f5);
        this.Leg5.render(f5);
        this.Leg3.render(f5);
        this.Leg1.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

