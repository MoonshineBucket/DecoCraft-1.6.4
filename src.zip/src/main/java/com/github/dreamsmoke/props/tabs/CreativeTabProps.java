package com.github.dreamsmoke.props.tabs;

import com.github.dreamsmoke.props.Props;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

public class CreativeTabProps extends CreativeTabs {
	
    public CreativeTabProps(String label) {
        super(label);
    }

    public Item getTabIconItem() {
        return Props.props;
    }
    
}

