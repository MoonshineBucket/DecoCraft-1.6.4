package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelPaperairplane extends ModelInterface {
	
    ModelRenderer Body;
    ModelRenderer Back;
    ModelRenderer Middle;
    ModelRenderer Tip;
    ModelRenderer Nose;

    public ModelPaperairplane() {
        super(6);
        this.setTexture("paperairplane.png");
        this.scaleItem = 1.6f;
        this.offsetInvY = -0.4f;
        this.textureWidth = 19;
        this.textureHeight = 14;
        this.Body = new ModelRenderer((ModelBase)this, -1, 6);
        this.Body.addBox(-10.0f, 0.0f, 0.0f, 10, 1, 0);
        this.Body.setRotationPoint(5.0f, 23.0f, 0.0f);
        this.Body.setTextureSize(19, 14);
        this.Body.mirror = true;
        this.setRotation(this.Body, 0.0f, 0.0f, 0.0f);
        this.Back = new ModelRenderer((ModelBase)this, 0, 0);
        this.Back.addBox(-3.0f, 0.0f, -3.0f, 3, 0, 6);
        this.Back.setRotationPoint(5.0f, 23.0f, 0.0f);
        this.Back.setTextureSize(19, 14);
        this.Back.mirror = true;
        this.setRotation(this.Back, 0.0f, 0.0f, 0.0f);
        this.Middle = new ModelRenderer((ModelBase)this, 0, 7);
        this.Middle.addBox(-3.0f, 0.0f, -2.0f, 3, 0, 4);
        this.Middle.setRotationPoint(2.0f, 23.0f, 0.0f);
        this.Middle.setTextureSize(19, 14);
        this.Middle.mirror = true;
        this.setRotation(this.Middle, 0.0f, 0.0f, 0.0f);
        this.Tip = new ModelRenderer((ModelBase)this, 0, 11);
        this.Tip.addBox(-3.0f, 0.0f, -1.0f, 3, 0, 2);
        this.Tip.setRotationPoint(-1.0f, 23.0f, 0.0f);
        this.Tip.setTextureSize(19, 14);
        this.Tip.mirror = true;
        this.setRotation(this.Tip, 0.0f, 0.0f, 0.0f);
        this.Nose = new ModelRenderer((ModelBase)this, 0, 13);
        this.Nose.addBox(0.0f, 0.0f, 0.0f, 1, 0, 1);
        this.Nose.setRotationPoint(-5.0f, 23.0f, -0.5f);
        this.Nose.setTextureSize(19, 14);
        this.Nose.mirror = true;
        this.setRotation(this.Nose, 0.0f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.Body.render(f5);
        this.Back.render(f5);
        this.Middle.render(f5);
        this.Tip.render(f5);
        this.Nose.render(f5);
    }
}

