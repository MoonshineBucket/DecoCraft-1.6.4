package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelGingerbreadhouse extends ModelInterface {
	
    ModelRenderer box4;
    ModelRenderer roof3;
    ModelRenderer roof2;
    ModelRenderer box1;
    ModelRenderer roof4;
    ModelRenderer base1;
    ModelRenderer Lolipop;
    ModelRenderer roof1;

    public ModelGingerbreadhouse() {
        super(154);
        this.setTexture("gingerbreadhouse2.png");
        this.setScale(0.5f);
        this.scaleItem = 2.0f;
        this.transparent = true;
        this.textureWidth = 64;
        this.textureHeight = 128;
        this.box4 = new ModelRenderer((ModelBase)this, 0, 64);
        this.box4.addBox(0.0f, 7.0f, 1.0f, 10, 2, 8);
        this.box4.setRotationPoint(-5.0f, 14.0f, -1.0f);
        this.box4.setTextureSize(64, 128);
        this.box4.mirror = true;
        this.setRotation(this.box4, 0.0f, 0.0f, 0.0f);
        this.roof3 = new ModelRenderer((ModelBase)this, 0, 28);
        this.roof3.addBox(0.0f, 0.0f, 0.0f, 3, 1, 8);
        this.roof3.setRotationPoint(-1.5f, 12.0f, 0.0f);
        this.roof3.setTextureSize(64, 128);
        this.roof3.mirror = true;
        this.setRotation(this.roof3, 0.0f, 0.0f, 0.0f);
        this.roof2 = new ModelRenderer((ModelBase)this, 0, 18);
        this.roof2.addBox(0.0f, 0.0f, 0.0f, 8, 1, 10);
        this.roof2.setRotationPoint(0.0f, 11.0f, -1.0f);
        this.roof2.setTextureSize(64, 128);
        this.roof2.mirror = true;
        this.setRotation(this.roof2, 0.0f, 0.0f, 0.5061455f);
        this.box1 = new ModelRenderer((ModelBase)this, 0, 46);
        this.box1.addBox(0.0f, 0.0f, 0.0f, 10, 7, 8);
        this.box1.setRotationPoint(-5.0f, 14.0f, 0.0f);
        this.box1.setTextureSize(64, 128);
        this.box1.mirror = true;
        this.setRotation(this.box1, 0.0f, 0.0f, 0.0f);
        this.roof4 = new ModelRenderer((ModelBase)this, 0, 37);
        this.roof4.addBox(0.0f, 0.0f, 0.0f, 7, 1, 8);
        this.roof4.setRotationPoint(-3.5f, 13.0f, 0.0f);
        this.roof4.setTextureSize(64, 128);
        this.roof4.mirror = true;
        this.setRotation(this.roof4, 0.0f, 0.0f, 0.0f);
        this.base1 = new ModelRenderer((ModelBase)this, 0, 84);
        this.base1.addBox(-1.0f, 12.0f, -1.0f, 16, 1, 16);
        this.base1.setRotationPoint(-7.0f, 11.0f, -7.0f);
        this.base1.setTextureSize(64, 128);
        this.base1.mirror = true;
        this.setRotation(this.base1, 0.0f, 0.0f, 0.0f);
        this.Lolipop = new ModelRenderer((ModelBase)this, 0, 0);
        this.Lolipop.addBox(-3.0f, 0.0f, 0.0f, 5, 7, 0);
        this.Lolipop.setRotationPoint(-4.0f, 16.0f, -4.0f);
        this.Lolipop.setTextureSize(64, 128);
        this.Lolipop.mirror = true;
        this.setRotation(this.Lolipop, 0.0f, -0.5235988f, 0.0f);
        this.roof1 = new ModelRenderer((ModelBase)this, 0, 18);
        this.roof1.addBox(0.0f, 0.0f, 0.0f, 8, 1, 10);
        this.roof1.setRotationPoint(-7.0f, 14.85f, -1.0f);
        this.roof1.setTextureSize(64, 128);
        this.roof1.mirror = true;
        this.setRotation(this.roof1, 0.0f, 0.0f, -0.5061455f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.box4.render(f5);
        this.roof3.render(f5);
        this.roof2.render(f5);
        this.box1.render(f5);
        this.roof4.render(f5);
        this.base1.render(f5);
        this.Lolipop.render(f5);
        this.roof1.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

