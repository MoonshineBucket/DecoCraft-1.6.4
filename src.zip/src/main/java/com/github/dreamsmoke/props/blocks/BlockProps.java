package com.github.dreamsmoke.props.blocks;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.ArrayList;

import com.github.dreamsmoke.props.Props;
import com.github.dreamsmoke.props.data.ModelData;
import com.github.dreamsmoke.props.tiles.TileProps;

import net.minecraft.block.Block;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.Icon;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockProps extends BlockContainer {
	
    public BlockProps() {
        super(Props.blockID, Material.cloth);
    }

    public void setBlockBoundsBasedOnState(IBlockAccess par1IBlockAccess, int x, int y, int z) {
        TileProps tile = (TileProps)par1IBlockAccess.getBlockTileEntity(x, y, z);
        if (tile == null) {
            return;
        }
        
        ModelData data = Props.data[tile.type];
        this.setBlockBounds(data.x1, data.y1, data.z1, data.x2, data.y2, data.z2);
    }

    public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int x, int y, int z) {
        TileProps tile = (TileProps)par1World.getBlockTileEntity(x, y, z);
        if (tile == null) {
            return super.getCollisionBoundingBoxFromPool(par1World, x, y, z);
        }
        
        ModelData data = Props.data[tile.type];
        if (data.walkthrough) {
            return null;
        }
        
        return super.getCollisionBoundingBoxFromPool(par1World, x, y, z);
    }

    public boolean isOpaqueCube() {
        return false;
    }

    public boolean renderAsNormalBlock() {
        return false;
    }

    public int getRenderType() {
        return -1;
    }

    public TileEntity createNewTileEntity(World world) {
        return new TileProps();
    }

    public ArrayList<ItemStack> getBlockDropped(World world, int x, int y, int z, int metadata, int fortune) {
        ArrayList<ItemStack> ret = new ArrayList<ItemStack>();
        return ret;
    }

    @SideOnly(value=Side.CLIENT)
    public int idPicked(World par1World, int par2, int par3, int par4) {
        return Props.props.itemID;
    }

    public int getLightValue(IBlockAccess world, int x, int y, int z) {
        TileProps tile = (TileProps)world.getBlockTileEntity(x, y, z);
        if (tile == null) {
            return 0;
        }
        
        ModelData data = Props.data[tile.type];
        return data.light;
    }

    public int getDamageValue(World world, int x, int y, int z) {
        TileProps tile = (TileProps)world.getBlockTileEntity(x, y, z);
        if (tile == null) {
            return 0;
        }
        
        return tile.type;
    }

    @SideOnly(value=Side.CLIENT)
    public void registerIcons(IconRegister par1IconRegister) {
    }

    public void onBlockHarvested(World world, int x, int y, int z, int par5, EntityPlayer par6EntityPlayer) {
        this.dropBlockAsItem_do(world, x, y, z, new ItemStack(Props.props.itemID, 1, this.getDamageValue(world, x, y, z)));
    }

    @SideOnly(value=Side.CLIENT)
    public Icon getIcon(int par1, int par2) {
        return Block.slowSand.getBlockTextureFromSide(par1);
    }
    
}

