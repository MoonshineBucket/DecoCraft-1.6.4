package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelPapelpicado extends ModelInterface {
	
    ModelRenderer Shape2;
    ModelRenderer Shape1;

    public ModelPapelpicado(String texture, int type) {
        super(type);
        this.setTexture(texture);
        this.setScale(0.45f);
        this.scaleItem = 1.0f;
        this.textureWidth = 128;
        this.textureHeight = 64;
        this.Shape2 = new ModelRenderer((ModelBase)this, 1, 2);
        this.Shape2.addBox(-19.0f, 0.0f, 0.0f, 38, 1, 0);
        this.Shape2.setRotationPoint(0.0f, 1.0f, 0.0f);
        this.Shape2.setTextureSize(128, 64);
        this.Shape2.mirror = true;
        this.setRotation(this.Shape2, 0.0f, 0.0f, 0.0f);
        this.Shape1 = new ModelRenderer((ModelBase)this, 7, 6);
        this.Shape1.addBox(-16.0f, -11.0f, 0.0f, 32, 22, 0);
        this.Shape1.setRotationPoint(0.0f, 13.0f, 0.0f);
        this.Shape1.setTextureSize(128, 64);
        this.Shape1.mirror = true;
        this.setRotation(this.Shape1, 0.0f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.Shape2.render(f5);
        this.Shape1.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

