package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelPresent1 extends ModelInterface {
	
    ModelRenderer Shape2;
    ModelRenderer Shape2lid;
    ModelRenderer bow1;
    ModelRenderer bow2;

    public ModelPresent1(String texture, int type) {
        super(type);
        this.setScale(0.4f);
        this.scaleItem = 1.1f;
        this.setTexture(texture);
        this.transparent = true;
        this.textureWidth = 256;
        this.textureHeight = 256;
        this.Shape2 = new ModelRenderer((ModelBase)this, 0, 0);
        this.Shape2.addBox(-6.0f, 0.0f, 1.0f, 18, 21, 18);
        this.Shape2.setRotationPoint(-3.0f, 3.0f, -10.0f);
        this.Shape2.setTextureSize(256, 256);
        this.Shape2.mirror = true;
        this.setRotation(this.Shape2, 0.0f, 0.0f, 0.0f);
        this.Shape2lid = new ModelRenderer((ModelBase)this, 76, 0);
        this.Shape2lid.addBox(-6.0f, 0.0f, 1.0f, 20, 4, 20);
        this.Shape2lid.setRotationPoint(-4.0f, -1.0f, -11.0f);
        this.Shape2lid.setTextureSize(256, 256);
        this.Shape2lid.mirror = true;
        this.setRotation(this.Shape2lid, 0.0f, 0.0f, 0.0f);
        this.bow1 = new ModelRenderer((ModelBase)this, 160, 0);
        this.bow1.addBox(-5.5f, 0.0f, 1.0f, 13, 8, 0);
        this.bow1.setRotationPoint(-1.0f, -9.0f, -2.0f);
        this.bow1.setTextureSize(256, 256);
        this.bow1.mirror = true;
        this.setRotation(this.bow1, 0.0f, 0.0f, 0.0f);
        this.bow2 = new ModelRenderer((ModelBase)this, 160, 8);
        this.bow2.addBox(-1.0f, 0.0f, -5.5f, 0, 8, 13);
        this.bow2.setRotationPoint(1.0f, -9.0f, -2.0f);
        this.bow2.setTextureSize(256, 256);
        this.bow2.mirror = true;
        this.setRotation(this.bow2, 0.0f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.Shape2.render(f5);
        this.Shape2lid.render(f5);
        this.bow1.render(f5);
        this.bow2.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

