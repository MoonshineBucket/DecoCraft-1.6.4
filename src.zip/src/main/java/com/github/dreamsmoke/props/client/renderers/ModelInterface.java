package com.github.dreamsmoke.props.client.renderers;

import com.github.dreamsmoke.props.client.renderers.RendererProps;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.util.ResourceLocation;

public class ModelInterface extends ModelBase {
	
    public ResourceLocation resource = null;
    public int type = -1;
    public float scaleX = 1.0f;
    public float scaleY = 1.0f;
    public float scaleZ = 1.0f;
    public int rotation = 0;
    public boolean transparent = false;
    public float scaleItem = 1.0f;
    public float offsetX = 0.0f;
    public float offsetY = 0.0f;
    public float offsetZ = 0.0f;
    public float offsetInvY = 0.0f;

    public ModelInterface(int type) {
        this.type = type;
        RendererProps.data[type] = this;
    }

    public void setRotation(ModelRenderer model, float x, float y, float z) {
        model.rotateAngleX = x;
        model.rotateAngleY = y;
        model.rotateAngleZ = z;
    }

    public void setScale(float scale) {
        this.scaleX = scale;
        this.scaleY = scale;
        this.scaleZ = scale;
    }

    public void setTexture(String texture) {
        this.resource = new ResourceLocation("props:textures/blocks/" + texture);
    }
    
}

