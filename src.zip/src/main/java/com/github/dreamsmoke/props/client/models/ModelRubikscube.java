package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelRubikscube extends ModelInterface {
	
    ModelRenderer Shape1;

    public ModelRubikscube(String texture, int type) {
        super(type);
        this.setTexture(texture);
        this.offsetInvY = -0.35f;
        this.scaleItem = 3.0f;
        this.textureWidth = 32;
        this.textureHeight = 32;
        this.Shape1 = new ModelRenderer((ModelBase)this, 0, 0);
        this.Shape1.addBox(0.0f, 0.0f, 0.0f, 3, 3, 3);
        this.Shape1.setRotationPoint(-1.5f, 21.0f, -1.0f);
        this.Shape1.setTextureSize(32, 32);
        this.Shape1.mirror = true;
        this.setRotation(this.Shape1, 0.0f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.Shape1.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

