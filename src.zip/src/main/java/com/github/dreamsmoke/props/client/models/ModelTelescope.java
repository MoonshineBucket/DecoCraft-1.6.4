package com.github.dreamsmoke.props.client.models;

import com.github.dreamsmoke.props.client.renderers.ModelInterface;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelTelescope extends ModelInterface {
	
    ModelRenderer Leg;
    ModelRenderer Leg2;
    ModelRenderer Leg3;
    ModelRenderer stand;
    ModelRenderer stand2;
    ModelRenderer Shape3;
    ModelRenderer Shape8;
    ModelRenderer Shape4;
    ModelRenderer Shape9;
    ModelRenderer Shape5;
    ModelRenderer Shape6;
    ModelRenderer Shape7;

    public ModelTelescope() {
        super(122);
        this.setTexture("Telescopetexture.png");
        this.setScale(0.6f);
        this.textureWidth = 64;
        this.textureHeight = 32;
        this.Leg = new ModelRenderer((ModelBase)this, 56, 0);
        this.Leg.addBox(-1.0f, -30.0f, -1.0f, 2, 30, 2);
        this.Leg.setRotationPoint(6.0f, 24.0f, -6.0f);
        this.Leg.setTextureSize(64, 32);
        this.Leg.mirror = true;
        this.setRotation(this.Leg, -0.2268928f, -0.6981317f, 0.0f);
        this.Leg2 = new ModelRenderer((ModelBase)this, 56, 0);
        this.Leg2.addBox(-1.0f, -30.0f, -1.0f, 2, 30, 2);
        this.Leg2.setRotationPoint(-6.0f, 24.0f, -6.0f);
        this.Leg2.setTextureSize(64, 32);
        this.Leg2.mirror = true;
        this.setRotation(this.Leg2, -0.2268928f, 0.6981317f, 0.0f);
        this.Leg3 = new ModelRenderer((ModelBase)this, 56, 0);
        this.Leg3.addBox(-1.0f, -30.0f, -1.0f, 2, 30, 2);
        this.Leg3.setRotationPoint(0.0f, 24.0f, 7.0f);
        this.Leg3.setTextureSize(64, 32);
        this.Leg3.mirror = true;
        this.setRotation(this.Leg3, 0.2268928f, 0.0f, 0.0f);
        this.stand = new ModelRenderer((ModelBase)this, 0, 0);
        this.stand.addBox(-1.0f, -1.0f, -1.0f, 4, 1, 4);
        this.stand.setRotationPoint(-1.5f, -5.0f, -0.5f);
        this.stand.setTextureSize(64, 32);
        this.stand.mirror = true;
        this.setRotation(this.stand, 0.0f, 0.7853982f, 0.0f);
        this.stand2 = new ModelRenderer((ModelBase)this, 0, 0);
        this.stand2.addBox(0.0f, 0.0f, 0.0f, 1, 3, 1);
        this.stand2.setRotationPoint(-0.5f, -9.0f, -1.0f);
        this.stand2.setTextureSize(64, 32);
        this.stand2.mirror = true;
        this.setRotation(this.stand2, 0.0f, 0.0f, 0.0f);
        this.Shape3 = new ModelRenderer((ModelBase)this, 0, 3);
        this.Shape3.addBox(-1.0f, -9.0f, -17.0f, 2, 1, 28);
        this.Shape3.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.Shape3.setTextureSize(64, 32);
        this.Shape3.mirror = true;
        this.setRotation(this.Shape3, -0.122173f, 0.0f, 0.0f);
        this.Shape8 = new ModelRenderer((ModelBase)this, 0, 3);
        this.Shape8.addBox(-1.0f, -12.0f, -17.0f, 2, 1, 28);
        this.Shape8.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.Shape8.setTextureSize(64, 32);
        this.Shape8.mirror = true;
        this.setRotation(this.Shape8, -0.122173f, 0.0f, 0.0f);
        this.Shape4 = new ModelRenderer((ModelBase)this, 0, 2);
        this.Shape4.addBox(-2.0f, -11.0f, -17.0f, 1, 2, 28);
        this.Shape4.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.Shape4.setTextureSize(64, 32);
        this.Shape4.mirror = true;
        this.setRotation(this.Shape4, -0.122173f, 0.0f, 0.0f);
        this.Shape9 = new ModelRenderer((ModelBase)this, 0, 2);
        this.Shape9.addBox(1.0f, -11.0f, -17.0f, 1, 2, 28);
        this.Shape9.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.Shape9.setTextureSize(64, 32);
        this.Shape9.mirror = true;
        this.setRotation(this.Shape9, -0.122173f, 0.0f, 0.0f);
        this.Shape5 = new ModelRenderer((ModelBase)this, 13, 8);
        this.Shape5.addBox(-1.0f, -11.0f, 11.0f, 2, 2, 3);
        this.Shape5.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.Shape5.setTextureSize(64, 32);
        this.Shape5.mirror = true;
        this.setRotation(this.Shape5, -0.122173f, 0.0f, 0.0f);
        this.Shape6 = new ModelRenderer((ModelBase)this, 0, 8);
        this.Shape6.addBox(-2.0f, -12.0f, -18.0f, 4, 4, 1);
        this.Shape6.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.Shape6.setTextureSize(64, 32);
        this.Shape6.mirror = true;
        this.setRotation(this.Shape6, -0.122173f, 0.0f, 0.0f);
        this.Shape7 = new ModelRenderer((ModelBase)this, 0, 15);
        this.Shape7.addBox(-2.5f, -12.5f, -21.0f, 5, 5, 3);
        this.Shape7.setRotationPoint(0.0f, 0.0f, 0.0f);
        this.Shape7.setTextureSize(64, 32);
        this.Shape7.mirror = true;
        this.setRotation(this.Shape7, -0.122173f, 0.0f, 0.0f);
    }

    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.Leg.render(f5);
        this.Leg2.render(f5);
        this.Leg3.render(f5);
        this.stand.render(f5);
        this.stand2.render(f5);
        this.Shape3.render(f5);
        this.Shape8.render(f5);
        this.Shape4.render(f5);
        this.Shape9.render(f5);
        this.Shape5.render(f5);
        this.Shape6.render(f5);
        this.Shape7.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
    }
}

